<?php
//get couter post
add_filter( 'the_content', function ($content) {
  $str = '';
  if( is_singular('post') && is_main_query() ) {
    $str='<div style="display: flex;
    justify-content: space-between;
    margin-bottom: 16px;
    font-size: 12px;
    font-weight: normal;
    margin-top: 16px;">
        <div>Người đăng: '.get_the_author().'</div>
        <div>
          '.getPostViews(get_the_ID()).' Lượt xem
        </div>
    </div>';

    setPostViews(get_the_ID());
  }

  return $str.$content;
});
// add_filter( 'the_content', function($str){

//     return $str.'[block id="lien-he-tu-ech"]';
// }, 10 );



// if (!is_admin()) {
//   include_once __DIR__."/front.php";
// }else{
//    include_once __DIR__."/admin.php";

// }


// add_action('wp_logout',function(){
//   global $ahlu_info;
//   if($ahlu_info){
//     setcookie("r", $a, time() + (86400 * 30), "/"); // 86400 = 1 day
//   }
  
//   // $current_user = wp_get_current_user(); 
//   // wp_redirect( home_url().'/?userid='.$current_user->ID ); 
//   // exit; 
// });
// add_filter('upload_dir',function( $param ){
//   global $ahlu_info;
  
  
//   if($ahlu_info){
//      foreach ($param as $k => $v) {
//       // $v = str_replace($_SERVER["DOCUMENT_ROOT"],$_SERVER["DOCUMENT_ROOT"].$ahlu_info->path."/",$v);
//       // $v =preg_replace('/\/+/', '/', $v);


  

    
//       // $v = str_replace(site_url("/"),site_url($ahlu_info->path),$v);
//       // $param[$k] =  $v;

      
//     }
//     if(!is_dir($param["path"])){
//        mkdir($param["path"],0775,true);
//     }
//   }
//     // print_r($param);
//     // die();
//     return $param;
// });

function ahlu_site_url($url,$return=true){
 
    if(!$return){
      $url = $url .(stripos($url, "?")!==FALSE?"&":"?")."runinbg";
    }
 	return site_url($url);
}

function site_url_ajax(){
  
  return admin_url('admin-ajax.php');
}

 
?>