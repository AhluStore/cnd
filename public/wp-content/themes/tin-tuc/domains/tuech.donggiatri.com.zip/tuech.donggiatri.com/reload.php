<?php
$file_domain = ABSPATH."domain/{$host}.ahlu";
if(file_exists($file_domain)){
	$info  = file_get_contents($file_domain);
	if(trim($info)){
		$ahlu_info = json_decode($info);

		$dbs["DB_NAME"]=$ahlu_info->db->database;
		$dbs["DB_USER"]=$ahlu_info->db->user;
		$dbs["DB_PASSWORD"]=$ahlu_info->db->password;
		$dbs["DB_HOST"]=$ahlu_info->db->host;

		define( 'UPLOADS', ($ahlu_info->path?$ahlu_info->path:"domain/{$host}")."/wp-content/uploads" );
	}	
}


define( 'IS_TYPE', $ahlu_info && isset($ahlu_info->is_type)?$ahlu_info->is_type:false);
define( 'ROOT', ABSPATH );
define( 'ROOT_DOMAIN', ROOT."wp-content/domain/{$host}/" );
define( 'ROOT_DOMAIN_URL', "https://{$host}/wp-content/domain/{$host}/" );
define( 'ROOT_DOMAIN_CACHE', ROOT."wp-content/domain/{$host}/cache" );
define( 'ROOT_DOMAIN_VENDOR', is_object($ahlu_info)?ROOT.$ahlu_info->path."/upload/":ROOT."wp-content/uploads/");
if(!is_dir(ROOT_DOMAIN_VENDOR)){
	mkdir(ROOT_DOMAIN_VENDOR,0775,true);
}
?>