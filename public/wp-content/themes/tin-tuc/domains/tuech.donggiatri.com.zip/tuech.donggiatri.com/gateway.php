<?php
 //any
if(preg_match("/^\/login/",$gateway)){
    $file = __DIR__."/form/login.php";
}else if(preg_match("/^\/register/",$gateway)){
    $file = __DIR__."/form/register.php";
}else if(preg_match("/^\/ctv/",$gateway)){
    $file = __DIR__."/form/ctv.php";
}else if(preg_match("/^\/account/",$gateway)){
    $file = __DIR__."/form/account.php";
}else{
    $file = "";
}
