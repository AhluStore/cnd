<!DOCTYPE html>
<html lang="en">
<head>
    <base href="<?php echo ROOT_DOMAIN_URL ?>public/direct/">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <title>Ahlustore - Redirection Webpage</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="URL Shorterner for free by thebao.me">
    <meta name="keywords" content="URL Shorterner for free by thebao.me">
    <meta content="Ahlustore" name="author">
    <!-- favicon -->
    <link rel="shortcut icon" href="https://ahlustore.com/images/logoah.png">
    <!-- Pixeden Icon -->
    <link rel="stylesheet" type="text/css" href="pe-icon-7.css">

    <!-- css -->
    <link href="bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="style.css" rel="stylesheet" type="text/css">
    <meta property="og:url" content="https://ahlustore.com/">
    <meta property="og:type" content="Redirection webpage">
    <meta property="og:title" content="URL Shorterner for free by thebao.me">
    <meta property="og:description" content="URL Shorterner for free by thebao.me">
    <meta property="og:image" content="images/home-2-img.png">
</head>
<body>

    <!--Navbar Start-->
    <nav class="navbar navbar-expand-lg fixed-top navbar-custom navbar-light sticky sticky-dark">
        <div class="container">
            <!-- LOGO -->
            <a class="navbar-brand logo" href="index.php">
                <img src="https://ahlustore.com/images/logoah.png" alt="" height="20">
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <i class="mdi mdi-menu"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <ul class="navbar-nav ml-auto navbar-center" id="mySidenav">
                    <li class="nav-item active">
                        <a href="#" class="nav-link">Add link</a>
                    </li>
                </ul>

            </div>
        </div>
    </nav>
    <!-- Navbar End -->

    <!-- HOME START -->
    <section class="section home-2-bg" id="home">
        <div class="home-center">
            <div class="home-desc-center">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-5">
                            <div class="mt-40 home-2-content">
                                <h1 class="text-white font-weight-normal home-2-title display-4 mb-0">Ahlustore Redirection</h1>
                                <p class="text-white-70 mt-4 f-15 mb-0" id="redirectTo">Loading URL, please wait ...</p>
                                <div class="mt-5" id="goNow" style="display: none;">
                                    <a href="<?php echo $url ?>" class="btn btn-custom mr-4" id="urlgoNow">Redirect Now</a>
                                </div>
                            </div>
                        </div>
                        <!-- col end -->

                        <div class="col-lg-7">
                            <div class="mt-40 home-2-content position-relative">
                                <img src="home-2-img.png" alt="" class="img-fluid mx-auto d-block home-2-img mover-img">
                                <div class="home-2-bottom-img">
                                    <img src="homr-2-bg-bottom.png" alt="" class="img-fluid d-block mx-auto">
                                </div>
                            </div>
                        </div>
                        <!-- col end -->
                    </div>
                    <!-- row end -->
                </div>
                <!-- container end -->
            </div>
        </div>
    </section>
    <!-- HOME END -->

    <script src="jquery.min.js"></script>
    <script>
        $(function(){
            $('#redirectTo').text('You are directing to Website #<?php echo $home_page; ?> in 5s');
           setTimeout(function(){
                $('#goNow').show(); 
                setTimeout(function(){ window.location = "<?php echo $url ?>"; }, 5000);
           }, 2000);
        });
    </script>



</body></html>