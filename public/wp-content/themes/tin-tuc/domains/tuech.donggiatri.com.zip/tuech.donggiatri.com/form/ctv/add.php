<?php
 
    //ask server
    define("DB_HOST","localhost");
    define("DB_DATABASE","ahluposy_idwp");
    define("DB_PASSWORD","ahluposy_poshcm");
    define("DB_USER","ahluposy_poshcm");

    include_once dirname(__DIR__)."/db.php";
    
    extract($_REQUEST);
    
    
    // 'user_login' => '',
    //       'user_pass' => '123123@',
    //       'user_email' => time().'@gmail.com',
    //       'first_name' => '',
    //       'last_name' => '',
    //       'display_name' => '',
    //       'role' => 'cashier'
          
          
   
    
    $data = query("select * from user where username='{$user_login}'");
    
    if(!$data){
        $ip = isset($ip)?$ip:get_ip_client(); 
        $date = date("Y-m-d H:i:s");
        $api_key = password_hash($user_login,PASSWORD_DEFAULT);
        query("INSERT INTO `user` (`barcode`, `id_parent`, `username`, `ip`, `url_login`, `url_direct`, `last_login`, `log`, `notification`, `api_key`, `otp_code`, `server_pos`, `server_pos_role`, `id_outlet`, `shop_id`, `id_pos`) VALUES
                                ('$barcode',NULL, '$user_login', '$ip', '$url_login', '$url_direct', '$date', '[]', NULL, '', '{$api_key}', '{}', '$role', '$id_outlet', '$shop_id', '$id_pos')");
                                
        echo "'$user_login' assigned..";
    }else{
        echo "'$user_login' exist.";
    } 

?>
 
