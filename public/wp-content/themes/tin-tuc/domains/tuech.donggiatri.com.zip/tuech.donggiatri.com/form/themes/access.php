<?php
function dbConnect($SERVERNAME, $USERNAME, $PASSWORD, $DATABASE){
	$mysqli = new mysqli($SERVERNAME, $USERNAME, $PASSWORD, $DATABASE);

	// Check connection
	if ($mysqli->connect_error) {
	    die("Connection failed: " . $mysqli->connect_error);
	} 
	$mysqli -> set_charset("utf8");

	return $mysqli;
}



function query($sql){
	global $mysqli;
	$data =[];
    if(preg_match('/(select)/is', $sql, $m)){
        //select
        //cache now
        $file = dirname(__DIR__)."/sql/".md5($sql).".dump";
        if(file_exists($file)){
            //check time
            
        }
    }


	$list = $mysqli->query($sql);


	if(is_bool($list)){
		return null;
	}



	if(preg_match('/^(insert|update)/is', $sql, $m)){
		return mysqli_insert_id($mysqli);
	}else{
		while($Tx = $list->fetch_assoc()){
			$data[]=$Tx;
		}

        $file = dirname(__DIR__)."/sql/".md5($sql).".dump";
        // file_put_contents($file,json_encode($data,JSON_UNESCAPED_UNICODE));
	} 
	return count($data)?$data:null;
}
function query_first($sql){
	if(preg_match('/^(insert|update)/is', $sql, $m)){
		global $mysqli;
		$mysqli->query($sql);
		return mysqli_insert_id($mysqli);
	} 
	$data = query($sql ." limit 1");
	return is_array($data)&&count($data)?(object)$data[0]:null;
}

function query_table($tb,$q=""){
    $data = query("SHOW TABLES IN `{$tb}`");
    if(!$data&&$q){
        query($q);
    }
    return $data;
}

global $mysqli;
///////////////////https://wp.donggiatri.com/form/themes/?id=1233/////////////////////
$domain = str_replace("www.",'',$_SERVER['HTTP_HOST']);
$id = $_GET['id'];
if(!is_numeric($id)){
	$a = json_decode(base64_decode($id));
	$id = $a->id;
}



switch ($domain) {
	case "wp.donggiatri.com":
		// Create connection
		$mysqli = dbConnect("localhost", "ahluposy_woomart", "_woomart", "ahluposy_woomartstore");
		$file = __DIR__."/themes.json";
		$data =@json_decode(file_get_contents($file),true);


		$data =isset($data["theme_".$id])?$data["theme_".$id]:null;
		if($data){

			// print_r($data);
			// die();
			$sql = "update  wp_options set option_value='{$data["id"]}' where option_name='page_on_front'";
			query($sql);

		 
			query("update  wp_options set option_value='page' where option_name='show_on_front'");
			query("update  wp_options set option_value='{$data["header"]}' where option_name='whb_main_header'");
  

		    $url = isset($data->url)&&$data->url?$data->url:"https://wp.donggiatri.com/";
		    header("Location: ".$url);
		}else{
			echo "Can not find theme {$id}";
		}

	break;
	
	default:
		echo "faild";
	break;
}

