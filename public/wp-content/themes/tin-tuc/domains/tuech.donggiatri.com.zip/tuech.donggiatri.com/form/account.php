<?php
if(!isset($result)){
  header('Location: /form/ctv/register/'); 
  return;
}
?>
<!DOCTYPE html>
<html lang="en" >

<head>
<?php 
  $title ="Tài Khoản - CTV - TƯ ẾCH MIỀN TÂY";
  include_once __DIR__."/meta.php";
?>
<link rel='stylesheet' href='/domains/tuech.donggiatri.com/form/account.css?t=<?php echo time(); ?>'>
<style>


#inline_cal{min-height: 400px;}


.modal:not(.bootbox){
    padding: 16px; 
}
.modal:not(.bootbox) .modal-dialog{
    border-radius: 8px;
    overflow: hidden;
}


td span.total{

    font-size: 10px;
    color: #673AB7;
    position: absolute;
    bottom: 0;
    left: 0;
        display: block;
    width: 100%;
}
</style>
 
  
</head>

<body translate="no">
  <!-- https://dribbble.com/shots/15392711-Dashboard-Login-Sign-Up/-->

<div class="login-container">
  <form action="https://tuech.donggiatri.com/form/ctv/" class="login-form" method="post">
      <input type="hidden" name="_token" value="<?php echo password_hash($_SERVER["HTTP_HOST"], PASSWORD_DEFAULT) ?>" />
     <div class="login-form-inner" style="">
    
      <div class="header flex-row">
          <div class="logo ripple"><svg height="512" viewBox="0 0 192 192" width="512" xmlns="http://www.w3.org/2000/svg">
          <path d="m155.109 74.028a4 4 0 0 0 -3.48-2.028h-52.4l8.785-67.123a4.023 4.023 0 0 0 -7.373-2.614l-63.724 111.642a4 4 0 0 0 3.407 6.095h51.617l-6.962 67.224a4.024 4.024 0 0 0 7.411 2.461l62.671-111.63a4 4 0 0 0 .048-4.027z" />
        </svg></div>
        <div class="title">
          <div>FAUCET</div>
          <div>Huan luyen vien</div>
        </div>
        <div class="actions">
           <i class="fa fa-qrcode btnqrcode" aria-hidden="true"></i>
           <i class="fa fa-bell" aria-hidden="true"></i>
           <i class="fa fa-bars" aria-hidden="true"></i>
        </div>
      </div>
       
      <div class="body">
        <div class="main-head" id="inline_cal"> </div>
         
        <p class="ptitle">Thông tin chung</p>
        <div class="all  text-center">
          <a class="white-view" href="#" title="Bán hàng" target="blank">
             <div class="block1 flex-row">
                <i class="fa fa-bell color-primay1" aria-hidden="true"></i>
                <i class="fa fa-bars" aria-hidden="true"></i>
             </div>
             <div class="block2">
                <div class="circle bg-primay1">
                  <i class="fa fa-bars" aria-hidden="true"></i>
                </div>
                <div class="pointbox" data-percent="20">
                    <svg class="round" viewBox="0 0 100 100" style="stroke-dasharray: 360;">  <circle cx="50" cy="50" r="40"></circle>  </svg>
                    <svg class="round run" viewBox="0 0 100 100"  style="stroke-dasharray: 0;"> <circle cx="50" cy="50" r="40"></circle>   </svg>
                </div>
             </div>
             <div class="block3 color-primay1">
                <p class="ptitle">Điểm bán hàng</p>
                <p>150</p>
             </div> 
          </a>
          <div class="white-view">
             <div class="block1 flex-row">
                <i class="fa fa-bell color-primay2" aria-hidden="true"></i>
                <i class="fa fa-bars" aria-hidden="true"></i>
             </div>
             <div class="block2">
                <div class="circle bg-primay2">
                  <i class="fa fa-bars" aria-hidden="true"></i>
                </div>
                <div class="pointbox purple" data-percent="20">
                    <svg class="round" viewBox="0 0 100 100" style="stroke-dasharray: 360;">  <circle cx="50" cy="50" r="40"></circle>  </svg>
                    <svg class="round run" viewBox="0 0 100 100"  style="stroke-dasharray: 0;"> <circle cx="50" cy="50" r="40"></circle>   </svg>
                </div>
             </div>
             <div class="block3">
                <p class="ptitle">Doanh số</p>
                <p>150</p>
             </div> 
          </div>
          <div class="white-view">
             <div class="block1 flex-row">
                <i class="fa fa-bell color-primay3" aria-hidden="true"></i>
                <i class="fa fa-bars" aria-hidden="true"></i>
             </div>
             <div class="block2">
                <div class="circle bg-primay3">
                  <i class="fa fa-bars" aria-hidden="true"></i>
                </div>
                <div class="pointbox" data-percent="10">
                    <svg class="round" viewBox="0 0 100 100" style="stroke-dasharray: 360;">  <circle cx="50" cy="50" r="40"></circle>  </svg>
                    <svg class="round run" viewBox="0 0 100 100"  style="stroke-dasharray: 0;"> <circle cx="50" cy="50" r="40"></circle>   </svg>
                </div>
             </div>
             <div class="block3 color-primay3">
                <p class="ptitle">Tháng này</p>
                <p>150</p>
             </div> 
          </div>
          <div class="white-view">
             <div class="block1 flex-row">
                <i class="fa fa-bell" aria-hidden="true"></i>
                <i class="fa fa-bars" aria-hidden="true"></i>
             </div>
             <div class="block2">
                <div class="circle">
                  <i class="fa fa-bars" aria-hidden="true"></i>
                </div>
                <div class="pointbox" data-percent="40">
                    <svg class="round" viewBox="0 0 100 100" style="stroke-dasharray: 360;">  <circle cx="50" cy="50" r="40"></circle>  </svg>
                    <svg class="round run" viewBox="0 0 100 100"  style="stroke-dasharray: 0;"> <circle cx="50" cy="50" r="40"></circle>   </svg>
                </div>
             </div>
             <div class="block3  color-primay2">
                <p class="ptitle">Hoa hồng</p>
                <p>150</p>
             </div> 
          </div>
        </div>
    
      
       <p class="rounded-button login-cta ripple" style="border-radius: 8px;">Chào mừng bạ tham gia nhóm CTV của chúng tôi</p>
        
       
        <p class="ripple">Quyền lợi cộng tác viên: 30%</p>
       
 
    </div>
    <div class="footer visible-sm visible-xs">  
        <div>
             <span class="active ripple"><i class="fa fa-user" aria-hidden="true"></i>Acc
             </span>
        <span class="ripple"><a target="_blank" href="https://f7.ahlupos.com/users/demo/chat/dist/?fullname_user=<?php echo $username ?>#/chat/support/client/<?php echo $username ?>"><i class="fa fa-comments" aria-hidden="true"></i>Chat</a></span>
        <span class="ripple"><a href="#accessarea" data-toggle="modal"><img src="https://cdn-icons-png.flaticon.com/128/1029/1029023.png" alt=""></a>Sale</span>
        <span class="ripple"><i class="fa fa-bars" aria-hidden="true"></i>AXs</span>
         <span class="ripple"><i class="fa fa-sign-out" aria-hidden="true"></i>Logout</span>
        </div>
    </div>
    </div>

  </form>
  <div class="onboarding">
    <div class="swiper-container">
      <div class="swiper-wrapper">
        <div class="swiper-slide color-1">
          <div class="slide-image">
            <img src="https://raw.githubusercontent.com/ismailvtl/ismailvtl.github.io/master/images/startup-launch.png" loading="lazy" alt="" />
          </div>
          <div class="slide-content">
            <h2>Turn your ideas into reality.</h2>
            <p>Consistent quality and eperience across all platform and devices</p>
          </div>
        </div>
        <div class="swiper-slide color-1">
          <div class="slide-image">
            <img src="https://raw.githubusercontent.com/ismailvtl/ismailvtl.github.io/master/images/cloud-storage.png" loading="lazy" alt="" />
          </div>
          <div class="slide-content">
            <h2>Turn your ideas into reality.</h2>
            <p>Consistent quality and eperience across all platform and devices</p>
          </div>
        </div>

        <div class="swiper-slide color-1">
          <div class="slide-image">
            <img src="https://raw.githubusercontent.com/ismailvtl/ismailvtl.github.io/master/images/cloud-storage.png" loading="lazy" alt="" />
          </div>
          <div class="slide-content">
            <h2>Turn your ideas into reality.</h2>
            <p>Consistent quality and eperience across all platform and devices</p>
          </div>
        </div>
      </div>
      <!-- Add Pagination -->
      <div class="swiper-pagination"></div>
    </div>
  </div>
</div>
 
<script src='https://faucet.donggiatri.com/js/faucet.min.js?t=<?php echo time(); ?>'></script>  
<script src='https://tuech.donggiatri.com/wp-content/themes/app.js?t=<?php echo time(); ?>'></script>  
<script src='https://tuech.donggiatri.com/form/style.js?t=<?php echo time(); ?>'></script>  
<script >
 
$(document).on("onUser",function(a,u){
  if(u){
   
  }
});
$(document).ready(function(){ 

    $('.pointbox').each(function () {

      var point = $(this);
      var roundPercent = point.attr("data-percent");

      point.find(".round").attr("data-percent",roundPercent);
      var $round = point.find(".round.run");

     var roundRadius = $round.find('circle').attr('r'),
      roundCircum = 2 * roundRadius * Math.PI,
      roundDraw = roundPercent * roundCircum / 100;
      $round.css('stroke-dasharray', roundDraw + ' 999');
    });


    

      $("#inline_cal").ACalandar({
        onClick : function(e){
            var v = $(this).data("info");
            console.log(v);
            if(v){

                var message =`
                    <p>Chi nhánh: ${v.branch}</p>
                    <p>Điểm bán hàng:${v.register_name}</p>
                    <p>Danh thu: ${v.total_sales}</p>
                    <p>Thời gian: ${v.opened} - ${v.closed}</p>
                `;
                alertbox("Báo cáo "+e.date,message,true);
            }
        }
      });


      window.APPHOST.ping();
 
 $(".btnqrcode").on("click",function(){
    window.Qrcode(function(code){
      alert(code);
                    //barcode
                    //user
                    //payment

    });
 });

  var swiper = new Swiper(".swiper-container", {
    pagination: ".swiper-pagination",
    paginationClickable: true,
    parallax: true,
    speed: 600,
    autoplay: 3500,
    loop: true,
    grabCursor: true 
  });
  window.user.fetch(function(u){
    
  });
});
 

</script>



<!-- Modal -->
<style>
    #accessarea{}
     

</style>
<div class="modal fade modal-flex" data-in='fadeInUp' data-out='fadeInDown' id="accessarea" role="dialog" aria-labelledby="MymodalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true" title="close"><i class="far fa-chevron-left"></i></button>
          <h4 class="modal-title">Làm việc</h4>
        </div>
        <!--  -->
        <div class="modal-body">
            <?php echo $result ?>
        </div>
        <!--  -->
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Dóng</button> 
        </div>
      </div>
    </div>
</div>
<script>

$(document).ready(function(){

    var submit = false;
    var namemodal = "#accessarea";
    var modal = $(namemodal);

     
    modal.on('shown.bs.modal', function (e) {
       
    }).on('hidden.bs.modal', function (e) {
        
    }).on('back.bs.modal', function (e) {
         
    });
});
</script>
<!-- End Modal -->
 
</body>

</html>
