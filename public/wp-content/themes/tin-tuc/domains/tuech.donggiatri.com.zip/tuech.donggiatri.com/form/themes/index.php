<?php
$token =  password_hash($_SERVER["HTTP_HOST"], PASSWORD_DEFAULT);
// $sites = [
//   ["id"=>"45849","title"=>"[Mã code 45849] Full code website hải sản Theme Flatsome","image"=>"https://topcode.vn/FilesUpload/CodeLarge/full-code-website-hai-san-theme-flatsome-10523.jpg","url"=>""],
//   ["id"=>"45839","title"=>"[Mã code 45849] Full code website hải sản Theme Flatsome","image"=>"https://topcode.vn/FilesUpload/CodeLarge/full-code-website-hai-san-theme-flatsome-10523.jpg","url"=>""],
//   ["id"=>"45829","title"=>"[Mã code 45849] Full code website hải sản Theme Flatsome","image"=>"https://topcode.vn/FilesUpload/CodeLarge/full-code-website-hai-san-theme-flatsome-10523.jpg","url"=>""],
//   ["id"=>"45819","title"=>"[Mã code 45849] Full code website hải sản Theme Flatsome","image"=>"https://topcode.vn/FilesUpload/CodeLarge/full-code-website-hai-san-theme-flatsome-10523.jpg","url"=>""],
// ];
$sites =@json_decode(file_get_contents(__DIR__."/themes.json"),true);
?>

<!DOCTYPE html>
<html lang="en" >

<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="apple-mobile-web-app-title" content="My App">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="viewport" content="viewport-fit=cover,width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
  <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
  <meta name="auth-token" content="">

  <!-- Color theme for statusbar (Android only) -->
  <meta name="theme-color" content="#2196f3">
  <title>Themplate - Tu Ech </title>
   <link rel='stylesheet' href='https://faucet.donggiatri.com/css/faucet.min.css?t=3'> 

   <link rel='stylesheet' href='../style.css?t=1'>
  
<style>
  body,html{
    overflow: hidden;
    height: 100%;
  }
 .login-container .rounded-button.small{
      padding: 6px 10px;
 }
 .actions {
  display: flex;
 }
 .login-container{
  max-width: 50%;
    min-width: 50%;
 }
  .login-container ,.onboarding{
      height: 100%;
 }
 .login-form{
  padding: 16px!important;
    flex-direction: column!important;
    align-items: flex-start!important;
    width: 100%!important;

 }

 .grid{
        width: 100%;
    height: 100%;
    overflow-x: hidden;
    overflow-y: auto;
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    justify-content: space-around;
 }
.grid .item{
      margin-bottom: 16px; width: 23%;
}
.grid .item{
 
}
</style>
 
  
</head>

<body translate="no">
 
<div class="login-container">
  <form class="login-form" method="post">
    
    
       <div class="grid">
        <?php
        foreach ($sites as $v) {
          $v["url_preview"] = $v["url_preview"]?$v["url_preview"]:"https://wp.donggiatri.com/form/themes/access/?id={$v["id"]}&_t=".$token;


          $data = base64_encode(json_encode($v));
          //


          

          $url_preview = "https://wp.donggiatri.com/form/themes/preview/?id={$data}&_t=".$token;
          $url_setup = "https://wp.donggiatri.com/form/themes/access/?id={$data}&_t=".$token;

            echo '<div class="item">
            <div class="img">
              <img class="ripple" src="'.$v["image"].'" width="215" alt="'.$v["title"].'"></div>
            <div class="title">'.$v["title"].'</div>
            <div class="actions">
                <a href="'.$url_setup.'" target="_blank" title="'.$v["title"].'" class="rounded-button login-cta small">Cài đặt</a>
               <a class="rounded-button login-cta small" href="'.$url_preview.'" target="_blank" title="'.$v["title"].'">Xem ngay</a>
            </div>
          </div>';
        }
?>
   
      </div>
    </div>

  </form>
  <div class="onboarding flex">
    <div class="swiper-container">
      <div class="swiper-wrapper">
        <div class="swiper-slide color-1">
          <div class="slide-image">
            <img src="https://raw.githubusercontent.com/ismailvtl/ismailvtl.github.io/master/images/startup-launch.png" loading="lazy" alt="" />
          </div>
          <div class="slide-content">
            <h2>Turn your ideas into reality.</h2>
            <p>Consistent quality and eperience across all platform and devices</p>
          </div>
        </div>
        <div class="swiper-slide color-1">
          <div class="slide-image">
            <img src="https://raw.githubusercontent.com/ismailvtl/ismailvtl.github.io/master/images/cloud-storage.png" loading="lazy" alt="" />
          </div>
          <div class="slide-content">
            <h2>Turn your ideas into reality.</h2>
            <p>Consistent quality and eperience across all platform and devices</p>
          </div>
        </div>

        <div class="swiper-slide color-1">
          <div class="slide-image">
            <img src="https://raw.githubusercontent.com/ismailvtl/ismailvtl.github.io/master/images/cloud-storage.png" loading="lazy" alt="" />
          </div>
          <div class="slide-content">
            <h2>Turn your ideas into reality.</h2>
            <p>Consistent quality and eperience across all platform and devices</p>
          </div>
        </div>
      </div>
      <!-- Add Pagination -->
      <div class="swiper-pagination"></div>
    </div>
  </div>
</div>
<script src='https://faucet.donggiatri.com/js/faucet.min.js?t=1'></script> 
      <script id="rendered-js" >
        $(document).ready(function(){ 

var swiper = new Swiper(".swiper-container", {
  pagination: ".swiper-pagination",
  paginationClickable: true,
  parallax: true,
  speed: 600,
  autoplay: 3500,
  loop: true,
  grabCursor: true });
 $("form").validate({

    submitHandler : function(form){

     

      form.submit();
    }
  });
  });
    </script>

  
</body>

</html>
