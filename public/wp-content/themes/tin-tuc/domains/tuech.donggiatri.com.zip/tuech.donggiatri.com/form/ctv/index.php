<?php
session_start();
// session_destroy();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$msg = "";
$result = "";
$file = __DIR__."/view/login.php";

    $domain = $_SERVER['HTTP_HOST'];
 
//ask server
switch($domain){
 case "tuechmientay.click":
    define("DB_HOST","localhost");
        define("DB_DATABASE","donggiat_idwp");
        define("DB_PASSWORD","_donggiatri");
        define("DB_USER","donggiat_admin");
 break;
 default:
   define("DB_HOST","localhost");
    define("DB_DATABASE","ahluposy_idwp");
    define("DB_PASSWORD","ahluposy_poshcm");
    define("DB_USER","ahluposy_poshcm");
 break;

   
}

 
include_once dirname(__DIR__)."/db.php";

if(isset($_SESSION['__u'])){
    $v = json_decode($_SESSION['__u']);
    $v = isset($v->data)?$v->data:$v;
    $user = $v;
 
    $ip  =get_ip_client();

    // print_r($data);
        $url = "https://{$_SERVER['HTTP_HOST']}/pos-ctv-token/".(stripos($v->url_pos,"?")!==FALSE?"&":"?")."token={$v->token}&ip={$ip}&_nonce={$v->_nonce}&time={$v->time}&url=".rawurlencode($v->url_pos);
        $result.='<a  class="rounded-button ripple login-cta" href="'.$url.'" target="_blank">Bán hàng</a>';
                    $url_sale = $url;
        
        $result='<p>Access area:</p><div style="display: flex;justify-content: space-around;">'.$result.'</div>';
        
        // $file = __DIR__."/view/result.php";
        // 
        include_once __DIR__."/account.php";
        return;
}else if(count($_POST)>0){
    $_POST["ip"] = get_ip_client();

    
    extract($_POST);
   


    // echo $res = ahlu_post("https://{$_SERVER['HTTP_HOST']}/api/ctv_login/",$_POST);
    // echo "https://{$_SERVER['HTTP_HOST']}/wp-admin/admin-ajax.php?action=ctv_login";
    $res = ahlu_post("https://{$_SERVER['HTTP_HOST']}/wp-admin/admin-ajax.php?action=ctv_login",$_POST);
    $data = @json_decode($res);
 
    if($data){
      if($data->code){
          $v = $data->data;
          $_SESSION['__u'] = json_encode($v);
            // print_r($data);
            $url = "https://{$_SERVER['HTTP_HOST']}/pos-ctv-token/".(stripos($v->url_pos,"?")!==FALSE?"&":"?")."token={$v->token}&ip={$ip}&_nonce={$v->_nonce}&time={$v->time}&url=".rawurlencode($v->url_pos);
            $result.='<a  class="rounded-button ripple login-cta" href="'.$url.'" target="_blank">Bán hàng</a>';
                        $url_sale = $url;
            
            $result='<p>Access area:</p><div style="display: flex;justify-content: space-around;">'.$result.'</div>';
            
            // $file = __DIR__."/view/result.php";
            
            $user = $v;
            include_once __DIR__."/account.php";

            return;
         
        }else{
            $msg='<p>Error:</p><div style="display: flex;
        justify-content: space-around;">Invalid '.$data->error.'</div>';
        }
     
    }else{
        $msg='<p>Error:</p><div style="display: flex;
    justify-content: space-around;">Invalid </div>';
    }
   
}
?>

<!DOCTYPE html>
<html lang="en" >

<head>
<?php 
  $title ="Đăng nhập - CTV ";
  include_once dirname(__DIR__)."/meta.php";
?>
<style>
 .modal.active{
  display: block;
 }
</style>
 
  
</head>

<body translate="no">
  <!-- https://dribbble.com/shots/15392711-Dashboard-Login-Sign-Up/-->

<div class="login-container">
  <form class="login-form" method="post">
    <?php include_once $file; ?>  
  </form>
  <div class="onboarding">
    <div class="swiper-container">
      <div class="swiper-wrapper">
        <div class="swiper-slide color-1">
          <div class="slide-image">
            <img src="https://raw.githubusercontent.com/ismailvtl/ismailvtl.github.io/master/images/startup-launch.png" loading="lazy" alt="" />
          </div>
          <div class="slide-content">
            <h2>Turn your ideas into reality.</h2>
            <p>Consistent quality and eperience across all platform and devices</p>
          </div>
        </div>
        <div class="swiper-slide color-1">
          <div class="slide-image">
            <img src="https://raw.githubusercontent.com/ismailvtl/ismailvtl.github.io/master/images/cloud-storage.png" loading="lazy" alt="" />
          </div>
          <div class="slide-content">
            <h2>Turn your ideas into reality.</h2>
            <p>Consistent quality and eperience across all platform and devices</p>
          </div>
        </div>

        <div class="swiper-slide color-1">
          <div class="slide-image">
            <img src="https://raw.githubusercontent.com/ismailvtl/ismailvtl.github.io/master/images/cloud-storage.png" loading="lazy" alt="" />
          </div>
          <div class="slide-content">
            <h2>Turn your ideas into reality.</h2>
            <p>Consistent quality and eperience across all platform and devices</p>
          </div>
        </div>
      </div>
      <!-- Add Pagination -->
      <div class="swiper-pagination"></div>
    </div>
  </div>
</div>
 
<script src='https://faucet.donggiatri.com/js/faucet.min.js?t=1'></script> 
      <script id="rendered-js" >

$(document).ready(function(){ 
  var swiper = new Swiper(".swiper-container", {
    pagination: ".swiper-pagination",
    paginationClickable: true,
    parallax: true,
    speed: 600,
    autoplay: 3500,
    loop: true,
    grabCursor: true });
});
 $("form").validate({

    submitHandler : function(form){

     

      form.submit();
    }
  });
    </script>

  
</body>

</html>
