<?php
function ahlu_post($url,$data,$res=false,$headers=array()){
    $ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_POST, 1);
// Edit: prior variable $postFields should be $postfields;
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); // On dev server only!p
curl_setopt($ch, CURLOPT_HTTPHEADER,$headers );
curl_setopt($ch, CURLOPT_REFERER, 'https://hcm.ahlupos.com/');
if(!$res){
  curl_setopt($ch, CURLOPT_TIMEOUT_MS, 1000);
}


$result = curl_exec($ch);

    return $result;
}

$msg = "";
$result = ""; 
if(count($_POST)>0){
    if(!password_verify($_SERVER["HTTP_HOST"], $_REQUEST["_token"])) {
        $msg = "Invalid request";
        return;
    }else{ 
   
       
    
        // $ip = get_ip_client();
        // $_REQUEST["ip"] = $ip;
        
       $a =ahlu_post("https://tuech.donggiatri.com/wp-admin/admin-ajax.php?action=wc_pos_create_cashier",$_POST,true);
        
      
        $res = @json_decode($a);
         
        if($res){     
            if($res->code){
                 $msg='<p>Access area:</p><div style="display: flex;justify-content: space-around;"><p>Đăng ký thành công</p><p><a href="'.$res->url.'">Truy cập ngay</a></p></div>'; 
            }else{
                 $msg='<p>Access area:</p><div style="display: flex;justify-content: space-around;">'.$res->error.'</div>'; 
            }
            
           
         
        }else{
            $msg='<p>Error:</p><div style="display: flex;
            justify-content: space-around;">Invalid </div>';
        }
    }
    // return;
}
?>

<!DOCTYPE html>
<html lang="en" >

<head>
  <?php 
  $title ="Đăng nhập - TƯ ẾCH MIỀN TÂY";
  include_once dirname(__DIR__)."/meta.php";
?>
  
<style>
 
</style>
 
  
</head>

<body translate="no">
  <!-- https://dribbble.com/shots/15392711-Dashboard-Login-Sign-Up/-->

<div class="login-container">
  <form class="login-form" method="post">
      <input type="hidden" name="_token" value="<?php echo password_hash($_SERVER["HTTP_HOST"], PASSWORD_DEFAULT) ?>" />
     <div class="login-form-inner">
      <div class="logo"><svg height="512" viewBox="0 0 192 192" width="512" xmlns="http://www.w3.org/2000/svg">
          <path d="m155.109 74.028a4 4 0 0 0 -3.48-2.028h-52.4l8.785-67.123a4.023 4.023 0 0 0 -7.373-2.614l-63.724 111.642a4 4 0 0 0 3.407 6.095h51.617l-6.962 67.224a4.024 4.024 0 0 0 7.411 2.461l62.671-111.63a4 4 0 0 0 .048-4.027z" />
        </svg></div>
      <h1>Đăg ký CTV</h1>
    
      
      <div class="login-form-group">
        <label for="pwd">Tài khoản Email <span class="required-star">*</span></label>
        <input autocomplete="off" autofocus name='email'  required type="email" placeholder="Email" id="pwd">
      </div>
      
      <div class="login-form-group">
        <label for="pwdrew">Mật khẩu <span class="required-star">*</span></label>
        <input autocomplete="off" name='password' required type="password" placeholder="Min 6 characters" id="pwdrew">
      </div>
      
      
      <div class="login-form-group">
        <label for="pwdqs">Họ và tên <span class="required-star">*</span></label>
        <input autocomplete="off" name='display_name'  required type="text" placeholder="" id="pwdqs">
      </div>
        
  
      <div class="login-form-group">
        <label for="pwdsqs">Địa điểm đăng ký</label>
        <select  name='id_outlet'  id="pwdsqs">
            <option value="1">Quán ăn Tư Ếch - điểm chính</option>
            <option value="2">Quán ăn Tư Ếch - An Giang</option>
        </select>
      </div>
      <?php
        echo $msg;
         
      ?>

       

      <button  class="rounded-button login-cta">Create an account</button>
 
 
    </div>
    </div>

  </form>
  <div class="onboarding">
    <div class="swiper-container">
      <div class="swiper-wrapper">
        <div class="swiper-slide color-1">
          <div class="slide-image">
            <img src="https://raw.githubusercontent.com/ismailvtl/ismailvtl.github.io/master/images/startup-launch.png" loading="lazy" alt="" />
          </div>
          <div class="slide-content">
            <h2>Turn your ideas into reality.</h2>
            <p>Consistent quality and eperience across all platform and devices</p>
          </div>
        </div>
        <div class="swiper-slide color-1">
          <div class="slide-image">
            <img src="https://raw.githubusercontent.com/ismailvtl/ismailvtl.github.io/master/images/cloud-storage.png" loading="lazy" alt="" />
          </div>
          <div class="slide-content">
            <h2>Turn your ideas into reality.</h2>
            <p>Consistent quality and eperience across all platform and devices</p>
          </div>
        </div>

        <div class="swiper-slide color-1">
          <div class="slide-image">
            <img src="https://raw.githubusercontent.com/ismailvtl/ismailvtl.github.io/master/images/cloud-storage.png" loading="lazy" alt="" />
          </div>
          <div class="slide-content">
            <h2>Turn your ideas into reality.</h2>
            <p>Consistent quality and eperience across all platform and devices</p>
          </div>
        </div>
      </div>
      <!-- Add Pagination -->
      <div class="swiper-pagination"></div>
    </div>
  </div>
</div>
<script src='https://faucet.donggiatri.com/js/faucet.min.js?t=1'></script> 
      <script id="rendered-js" >
        $(document).ready(function(){ 

var swiper = new Swiper(".swiper-container", {
  pagination: ".swiper-pagination",
  paginationClickable: true,
  parallax: true,
  speed: 600,
  autoplay: 3500,
  loop: true,
  grabCursor: true });
 $("form").validate({

    submitHandler : function(form){

     

      form.submit();
    }
  });
  });
    </script>

  
</body>

</html>
