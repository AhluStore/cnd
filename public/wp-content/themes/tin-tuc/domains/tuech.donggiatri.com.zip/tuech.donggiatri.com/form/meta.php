 <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="apple-mobile-web-app-title" content="My App">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="viewport" content="viewport-fit=cover,width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
  <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
  <meta name="auth-token" content="<?php echo isset($user)?$user->token:"" ?>">

  <!-- Color theme for statusbar (Android only) -->
  <meta name="theme-color" content="#2196f3">
  <title><?php echo isset($title)?$title:"Login" ?></title>
  <link rel='stylesheet' href='https://faucet.donggiatri.com/css/faucet.min.css?t=3'> 

  <link rel='stylesheet' href='/domains/<?php echo $_SERVER["HTTP_HOST"] ?>/form/style.css?t=4'>