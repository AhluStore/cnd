



<script>
    

    (function(f){
        var md5_script = "242bf4a579298fe217241cda6c995a83";
        var doc = document.getElementsByTagName("html")[0];
        
        var html = window.localStorage.getItem(md5_script);
        if(html){
           doc.innerHTML = html;

            f();
        }else{
            fetch("https://tuech.donggiatri.com/point-of-sale/quan-an-tu-ech-diem-chinh/pos-a/").then(function(r){
                return r.text();
            }).then(function(html){
                  doc.innerHTML = html;
                  f();
            })

        }
    })(function(){
        // alert(1234);
    });
    
</script>