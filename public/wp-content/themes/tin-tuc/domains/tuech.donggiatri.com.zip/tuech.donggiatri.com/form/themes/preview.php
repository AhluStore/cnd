<?php
$token =  password_hash($_SERVER["HTTP_HOST"], PASSWORD_DEFAULT);
//check token
$data = json_decode(base64_decode($_GET["id"]));
?>

<!DOCTYPE html>
<html lang="en" >

<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="apple-mobile-web-app-title" content="My App">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="viewport" content="viewport-fit=cover,width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
  <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
  <meta name="auth-token" content="">

  <!-- Color theme for statusbar (Android only) -->
  <meta name="theme-color" content="#2196f3">
  <title>Preview - template</title>
   <link rel='stylesheet' href='https://faucet.donggiatri.com/css/faucet.min.css?t=3'> 

   <link rel='stylesheet' href='../style.css?t=1'>
  
<style>
  body,html{
    overflow: hidden;
        height: 100%;
    
  }
 .login-container .rounded-button.small{
      padding: 6px 10px;
 }
 
 .login-container{
      height: 100%;
   max-width: 100%;
    min-width: 100%;
    display: flex;
    flex-direction: column;
 }
 .login-form{
  padding: 0px!important;
    flex-direction: column!important;
    align-items: flex-start!important;
    width: 100%!important;

 }
.boxrow{
    padding: 16px!important;
      background-color: #673AB7;
    color: #fff;
     display: flex;
    flex-direction: row;
    justify-content: space-between;
}
iframe{
      width: 100%;
    height: 100%;
    border: 0;
    padding: 0;
}

.onboarding{
    display: flex;
    flex-direction: row;
}
.onboarding iframe{
    flex: 1;
}
</style>
 
  
</head>

<body translate="no">
 
<div class="login-container">
  <form class="login-form" method="post">
     <div class="boxrow">
        <div class="title"><?php echo $data->title ?></div>
        <div class="action">
           <a href="<?php  echo $data->url_preview ?>"><i class="fa fa-eye"></i> Preview</a>
           <a href="javascript:window.close()"><i class="fa fa-times"></i> Close</a>
        </div>
     </div>
  </form>
  <div class="onboarding loaddata flex">
     <iframe class="" src="" frameborder="0"></iframe>
     <div class="ads">
         
     </div>
  </div>
</div>
<script src='https://faucet.donggiatri.com/js/faucet.min.js?t=1'></script> 
      <script id="rendered-js" >
        window.fetch_website = function (url,func){
  fetch(url).then((a)=>a.text()).then((res)=>{
    var div = $('<div>'+res+'</div>');
    var obj = {title:div.find("title").html(),image:div.find('meta[property="og:image"]').attr("content"),description:div.find('meta[name="description"]').attr("content")};

    //find add preview
    if(div.find('meta[name="adspreview"]').length){
        obj.ads = div.find('meta[name="adspreview"]').attr("content");
        obj.adsurl = div.find('meta[name="adspreviewurl"]').attr("content");
    }
    

    func(obj);
  });
};
     setTimeout(function(){ 
        var url = "<?php  echo $data->url_preview ?>";
        fetch_website('https://f7.donggiatri.com/proxy.php?url='+encodeURIComponent(url),function(data){

            if(data.ads){
                $(".ads").html(`<a href="${v.adsurl}"><img src="${data.ads}" /></a>`);
            } 

          });
        $("iframe").attr({
          src:url,
          onload : function(){
            $(".onboarding").removeClass("loaddata");
          },
          onunload : function(){ 
          }
        });
      },2000);
    </script>

  
</body>

</html>
