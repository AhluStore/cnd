<?php
wp_enqueue_style( 'shop', content_url('domain/flowerwp.ahlustore.com/assets/style.css'),false,time(),'all');
wp_enqueue_script(
        'shop-js',
        content_url('domain/flowerwp.ahlustore.com/assets/front.js?t='.time()),false,time(),'all'
    );
  add_filter('upload_mimes',function($mimes) { 
  $mimes = array( 
        'jpg|jpeg|jpe' => 'image/jpeg', 
        'gif' => 'image/gif', 
        'png' => 'image/png', 
        'pdf' => 'application/pdf', 
        'pptx' => 'pplication/vnd.openxmlformats-officedocument.presentationml.presentation', 
        'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    ); 
    return $mimes;
  });


remove_action( 'wp_head', 'feed_links_extra', 3 ); // Display the links to the extra feeds such as category feeds
remove_action( 'wp_head', 'feed_links', 2 ); // Display the links to the general feeds: Post and Comment Feed
remove_action( 'wp_head', 'rsd_link' ); // Display the link to the Really Simple Discovery service endpoint, EditURI link
remove_action( 'wp_head', 'wlwmanifest_link' ); // Display the link to the Windows Live Writer manifest file.
remove_action( 'wp_head', 'index_rel_link' ); // index link
remove_action( 'wp_head', 'parent_post_rel_link', 10, 0 ); // prev link
remove_action( 'wp_head', 'start_post_rel_link', 10, 0 ); // start link
remove_action( 'wp_head', 'adjacent_posts_rel_link', 10, 0 ); // Display relational links for the posts adjacent to the current post.
remove_action( 'wp_head', 'wp_generator' ); // Display the XHTML generator that is generated on the wp_head hook, WP version
add_action( 'wp_head',function(){
  echo '<style>

  .submenu-header{
    position: absolute;
    top: 0;
    right: 0;
  }

  .page-id-8389{}
  .page-id-8389 .home-category{}
  .page-id-8389 .home-category .product-category{
    border-radius: 50%;
      overflow: hidden;
  }

  /*Shoppe*/
  .page-id-12850{}
  .page-id-12850 .shope-cate-home .category-grid-item{}
  .page-id-12850 .shope-cate-home .category-grid-item .category-title{ 
  text-transform: capitalize;
    font-size: 13px;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
}
  .page-id-12850 .shope-cate-home .category-grid-item .more-products{display:none;}

  /**/
  .page-id-13750{}
  .page-id-13750 .woodmart-title-container.title{
    border-bottom: 1px solid #e3e3e3;
    text-align: left;
      text-transform: uppercase;
  }

  /*xay dung*/
  .page-id-14460{}
  .page-id-14460 .featured_project{}
  @media (max-width: 1020px) {
    .page-id-14460 .featured_project .vc_column_container{margin-bottom: 8px;}
    .page-id-14460 .featured_project .vc-hoverbox-back{
          background-color: rgb(10 10 10 / 55%)!important;
          z-index: 100;
          backface-visibility: visible;
          -webkit-backface-visibility: visible;
    }
    .page-id-14460 .featured_project .vc-hoverbox-block-inner *{
      backface-visibility: visible;
          -webkit-backface-visibility: visible;
    }
  }
  

  .post-list-mobile{}
  .post-list-mobile .vc_grid-item-mini{
    display: flex;
      flex-direction: row;
  }
  .post-list-mobile .vc_grid-item-mini .vc_gitem-is-link{
    width: 85px;
      height: 85px;
      margin-right: 8px;
  }
  .post-list-mobile .vc_gitem-post-data-source-post_title{
    display: block;
      display: -webkit-box;
      max-width: 100%;
      height: 40px;
      overflow: hidden;
      text-overflow: ellipsis;
  }
  .post-list-mobile .vc_gitem-post-data-source-post_title h4{
    font-size: 0.9rem;
  }
  .post-list-mobile .vc_gitem-post-data-source-post_excerpt{
    display:none;
  }
  .post-list-mobile .vc_btn3-container{
    margin: 0;
  }
  .post-list-mobile .vc_btn3-container a{
        padding: 4px;
  }
  .post-list-mobile .vc_grid-item{
    padding: 0 0 8px 0!important;
      margin-bottom: 8px;
      border-bottom: 1px solid rgb(206 206 206 / 42%);
  }
  @media (max-width: 1020px) {
    .post-list-mobile .vc_gitem-post-data-source-post_title{
        
    }
  }
</style>';
});

Route::add("preview-([0-9]+)",function($home_page){
 // print_r($args);
  $default_home = 8389;


   if($home_page!=$default_home){

     $w = "h_{$home_page}";
     // switch($w){
     //  case "h_11692":
     //    //tree shop
     //    update_option( 'whb_main_header', "header_667631" );
     //  break;
     //  case "h_12499":
     //    //tgdd shop
     //    update_option( 'whb_main_header', "header_228226" );
     //  break;
     //  case "h_8389":
     //    //flower shop
     //    update_option( 'whb_main_header', "header_667631" );
     //  break;
     //  case "h_2303":
     //    //normal shop
     //    update_option( 'whb_main_header', "header_693265" );
     //  break;
     //  case "h_12672":
     //    //perfum shop
     //    update_option( 'whb_main_header', "header_401504" );
     //  break;
     //  case "h_12850":
     //    //shopee shop
     //    update_option( 'whb_main_header', "header_993867" );
     //  break;
     //  case "h_14123":
     //  case "h_14406":
     //  case "h_14670":
     //    //Cong ty xay dung
     //    update_option( 'whb_main_header', "header_532270" );
     //  break;


     //  case "h_14614":
     //    //Cong ty futa taxi
     //    update_option( 'whb_main_header', "header_362134" );
     //  break;
     //  // 
     //  case "h_13750":
     //    //Môt mini
     //    update_option( 'whb_main_header', "header_704263" );
     //  break;
     //  case "h_13750":
     //    //Điện lạnh
     //    update_option( 'whb_main_header', "header_704263" );
     //  break;
     //  case "h_15516":
     //    //Ống hút
     //    update_option( 'whb_main_header', "header_255159" );
     //  break;
     //  case "h_15859":
     //    //Shop bàn nghế
     //    update_option( 'whb_main_header', "header_629564" );
     //  break;

     //  case "h_16600":
     //    //Shop bàn nghế
     //    update_option( 'whb_main_header', "header_778847" );
     //  break;

     //  case "h_18794":
     //    //Shop KHOÁ HỌC
     //    update_option( 'whb_main_header', "header_993867" );
     //  break;

     //  case "h_19867":
     //  case "h_17858":
     //  case "h_17384":
     //  case "h_16600":
     //    //Shop Spa
     //    update_option( 'whb_main_header', "header_778847" );
     //  break;
     // }
      

      $data = json_decode(file_get_contents(__DIR__."/template.json"));
     // print_r($data->{$w}->header);
     // die();
     update_option( 'whb_main_header', $data->{$w}->header );

      update_option("page_on_front", $home_page,true);
      setcookie("_w", "", time() - 3600);
      setcookie("_w", $home_page, time() + (86400 * 30), "/"); // 86400 = 1 day
      //now redirect 
      
      //now open config
      $info = json_decode(file_get_contents(__DIR__."/config.json"));
      $info->home_page = $home_page;
      file_put_contents(__DIR__."/config.json",json_encode($info,JSON_PRETTY_PRINT));
      //save
      
   }else if(!isset($_COOKIE["_w"])){
    //Trang Chủ VN
     update_option("page_on_front", 8389,true);
     update_option( 'whb_main_header', "header_667631" );
  }

  $url= site_url();

  include_once ABSPATH."/public/direct/index.php";
});

/**
* multiple custom routing with one page
*/
add_filter( 'template_include',function ( $template ) {
  
 
    return $template;
},99);
?>