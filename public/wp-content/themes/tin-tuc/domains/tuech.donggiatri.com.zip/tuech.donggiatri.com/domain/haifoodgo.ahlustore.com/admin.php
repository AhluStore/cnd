<?php
/* Plugin Name: (#120589) Disable Plugin Updates */
// remove_action( 'load-update-core.php', 'wp_update_plugins' );
// you may want to wrap add_action() in a conditional to prevent enqueue on every page
add_action( 'admin_enqueue_scripts',function() {
    wp_enqueue_script(
        'possa',
        content_url('domain/flowerwp.ahlustore.com/assets/admin.js?t='.time()),false,time(),'all'
    );
    wp_enqueue_style( 'pos', content_url('domain/flowerwp.ahlustore.com/assets/admin.css'),false,time(),'all');
});
add_action( 'admin_head',function() {
    // This makes sure that the positioning is also good for right-to-left languages
    $x = is_rtl() ? 'left' : 'right';
    //check user use pos or all
    echo "
    <style type='text/css'>
    #xts_product_metaboxes,#woocommerce-product-360-images,#tagsdiv-product_tag,#postdivrich,#mymetabox_revslider_0,#postexcerpt {
       display: none;
    }
    #wp-admin-bar-wp-logo{
      background-image: url(".LOGO.")!important;
      width:32px;
      height:32px;
    background-size:cover!important;
    background-repeat:no-repeat!important;
    }
    </style>
  <script type='text/javascript'>
    jQuery(function($) {
      $('#footer-left span').html('Development by <a href=\'https://www.ahlustore.com/\' target=\'_blank\'>Ahlustore</a>');
      $('#footer-upgrade').html('Version 1.0');
    });
  </script>
    ";
});

add_action( 'wp_dashboard_setup', function() {

    remove_meta_box( 'dashboard_primary','dashboard','side' ); // WordPress.com Blog
    remove_meta_box( 'dashboard_plugins','dashboard','normal' ); // Plugins
    remove_meta_box( 'dashboard_right_now','dashboard', 'normal' ); // Right Now
    remove_action( 'welcome_panel','wp_welcome_panel' ); // Welcome Panel
    remove_action( 'try_gutenberg_panel', 'wp_try_gutenberg_panel'); // Try Gutenberg
    remove_meta_box('dashboard_quick_press','dashboard','side'); // Quick Press widget
    remove_meta_box('dashboard_recent_drafts','dashboard','side'); // Recent Drafts
    remove_meta_box('dashboard_secondary','dashboard','side'); // Other WordPress News
    remove_meta_box('dashboard_incoming_links','dashboard','normal'); //Incoming Links
    remove_meta_box('rg_forms_dashboard','dashboard','normal'); // Gravity Forms
    remove_meta_box('dashboard_recent_comments','dashboard','normal'); // Recent Comments
    remove_meta_box('icl_dashboard_widget','dashboard','normal'); // Multi Language Plugin
    remove_meta_box('dashboard_activity','dashboard', 'normal'); // Activity
    remove_meta_box('wpseo-dashboard-overview','dashboard', 'normal'); // Yoast seo

    // remove_meta_box('woocommerce_dashboard_status','dashboard', 'normal'); 
    
});

//check security
add_action( 'after_setup_theme',function() {
  $pages = array("plugins.php","page=xtemos_options","page=woodmart_dashboard");
  foreach($pages as $v){
    if(!is_site_admin() && stripos($uri,$v)!==FALSE){
        ahlu_die("Not allowed");
    }
  }

  $pages = array("acf-field-group");
  foreach($pages as $v){
    if(!is_site_admin() && get_post_type() == $v){
        ahlu_die("Not allowed");
    }
  }
});
?>