<?php

if (!is_admin()) {

  include_once __DIR__."/front.php";
}else{

   include_once __DIR__."/admin.php";

}

function ahlu_site_url($url,$return=true){
 
    if(!$return){
      $url = $url .(stripos($url, "?")!==FALSE?"&":"?")."runinbg";
    }
 	return site_url($url);
}

function site_url_ajax(){
  
  return admin_url('admin-ajax.php');
}

?>