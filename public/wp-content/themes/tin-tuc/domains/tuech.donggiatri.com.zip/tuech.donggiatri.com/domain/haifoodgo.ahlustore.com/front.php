<?php
wp_enqueue_style( 'shop', content_url('domain/flowerwp.ahlustore.com/assets/style.css'),false,time(),'all');
wp_enqueue_script('shop-js',content_url('domain/flowerwp.ahlustore.com/assets/front.js?t='.time()),false,time(),'all');

wp_enqueue_script('haisan-shop-js',content_url('domain/flowerwp.ahlustore.com/domain/haifoodgo.ahlustore.com/assets/front.js'),false,time(),'all');

wp_enqueue_style( 'shop-css', content_url('domain/flowerwp.ahlustore.com/domain/haifoodgo.ahlustore.com/assets/front.css'),false,time(),'all');

add_filter('upload_mimes',function($mimes) { 
  $mimes = array( 
        'jpg|jpeg|jpe' => 'image/jpeg', 
        'gif' => 'image/gif', 
        'png' => 'image/png', 
        'pdf' => 'application/pdf', 
        'pptx' => 'pplication/vnd.openxmlformats-officedocument.presentationml.presentation', 
        'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    ); 
    return $mimes;
});


remove_action( 'wp_head', 'feed_links_extra', 3 ); // Display the links to the extra feeds such as category feeds
remove_action( 'wp_head', 'feed_links', 2 ); // Display the links to the general feeds: Post and Comment Feed
remove_action( 'wp_head', 'rsd_link' ); // Display the link to the Really Simple Discovery service endpoint, EditURI link
remove_action( 'wp_head', 'wlwmanifest_link' ); // Display the link to the Windows Live Writer manifest file.
remove_action( 'wp_head', 'index_rel_link' ); // index link
remove_action( 'wp_head', 'parent_post_rel_link', 10, 0 ); // prev link
remove_action( 'wp_head', 'start_post_rel_link', 10, 0 ); // start link
remove_action( 'wp_head', 'adjacent_posts_rel_link', 10, 0 ); // Display relational links for the posts adjacent to the current post.
remove_action( 'wp_head', 'wp_generator' ); // Display the XHTML generator that is generated on the wp_head hook, WP version
add_action( 'wp_head',function(){
  echo '
<script>
if(window.innerWidth<1020){
 jQuery(function($){

    var parent = $(".myhome>.vc_col-sm-9>.vc_column-inner>.wpb_wrapper");
    parent.find(".vc-hoverbox-wrapper").wrapAll( "<div class=\'move-box\' />");
    $(".move-box").appendTo(parent);
    // $(".move-box .vc-hoverbox-wrapper").matchHeight();
 });
}

</script>
';
});
//try to update theme
update_option( 'whb_main_header',"header_805040" );
update_option("page_on_front", 46369,true);
?>