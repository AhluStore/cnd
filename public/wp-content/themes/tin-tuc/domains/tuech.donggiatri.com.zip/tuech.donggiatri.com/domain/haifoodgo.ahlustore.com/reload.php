<?php
if(isset($ahlu_info)){
	$dbs["DB_NAME"]=$ahlu_info->db->database;
	$dbs["DB_USER"]=$ahlu_info->db->user;
	$dbs["DB_PASSWORD"]=$ahlu_info->db->password;
	$dbs["DB_HOST"]=$ahlu_info->db->host;


	// get config from domain flower.ahlustore.com	
	$co = ABSPATH."domain/flowerwp.ahlustore.com.ahlu";
	if(file_exists($co)){
		$info  = json_decode(file_get_contents($co));
		define( 'UPLOADS', "{$info->path}wp-content/uploads" );
	}else{
		define( 'UPLOADS', ($ahlu_info->path?$ahlu_info->path:"domain/{$host}")."/wp-content/uploads" );
	}

	// die(UPLOADS);
	define( 'WP_HOME', 'https://'.$_SERVER['HTTP_HOST'] );
	define( 'WP_SITEURL', 'https://'.$_SERVER['HTTP_HOST'] );
}



function load_function(){
	include_once __DIR__."/functions.php"; 
}


define( 'ROOT', ABSPATH );
define( 'ROOT_DOMAIN', __DIR__);
define( 'ROOT_DOMAIN_URL', "https://{$host}/".UPLOADS);
define( 'ROOT_DOMAIN_CACHE', __DIR__."/cache/" );
// define( 'ROOT_DOMAIN_VENDOR', UPLOADS);
// if(!is_dir(ROOT_DOMAIN_VENDOR)){
// 	mkdir(ROOT_DOMAIN_VENDOR,0775,true);
// }
?>