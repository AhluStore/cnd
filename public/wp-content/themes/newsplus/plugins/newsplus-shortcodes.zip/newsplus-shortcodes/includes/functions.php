<?php
/**
 * Utility functions for the NewsPlus Theme
 */

function newsplus_mail( $to, $subject, $message, $headers ) {
	return wp_mail( $to, $subject, $message, $headers );
}
