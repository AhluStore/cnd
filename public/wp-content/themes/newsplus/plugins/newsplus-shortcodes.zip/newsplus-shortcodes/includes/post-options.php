<?php
/**
 * Post options panel
 * Used to generate post options inside post edit screen.
 */

$pls_post_key = 'post_options';
$pls_post_options = array();

function newsplus_create_post_options() {
	global $pls_post_key;
	if( function_exists( 'add_meta_box' ) ) {
		add_meta_box( 'pls_post_options_panel', esc_html__( 'Post Options', 'newsplus' ), 'newsplus_display_post_options', 'post', 'normal', 'high' );
	}
}
add_action( 'add_meta_boxes', 'newsplus_create_post_options' );

function newsplus_display_post_options() {
	global $post, $pls_post_options, $pls_post_key;

	$pls_post_options = apply_filters( 'pls_post_opts_array', $pls_post_options );
	$pls_post_key = apply_filters( 'pls_post_opts_key', $pls_post_key );
	?>
	<div id="newsplus-post-options">
		<?php wp_nonce_field( plugin_basename( __FILE__ ), $pls_post_key . '_wpnonce', false, true );
        foreach ( $pls_post_options as $meta_box ) {
			$data = get_post_meta( $post->ID, $pls_post_key, true );
			if( $meta_box['type'] == 'heading' ) {
				echo '<h4>' . esc_attr( $meta_box['description'] ) . '</h4>';
			}
			elseif ( $meta_box['type'] == 'text' ) { ?>
                <div>
                    <label for="<?php echo esc_attr( $meta_box['id'] ); ?>"><?php echo esc_attr( $meta_box['title'] ); ?></label>
                    <input type="text" name="<?php if ( isset( $meta_box['id'] ) ) echo esc_attr( $meta_box['id'] ); ?>" id="<?php if ( isset( $meta_box['id'] ) ) echo esc_attr( $meta_box['id'] ); ?>" value="<?php if ( isset( $data[ $meta_box['id'] ] ) ) echo wp_kses_post( $data[ $meta_box['id'] ] ); ?>" />
                    <p><?php if ( isset( $meta_box['description'] ) ) echo wp_kses_post( $meta_box['description'] ); ?></p>
                </div>
			<?php }
			elseif ( $meta_box['type'] == 'textarea' ) { ?>
                <div>
                    <label for="<?php echo esc_attr( $meta_box['id'] ); ?>"><?php echo esc_attr( $meta_box['title'] ); ?></label>
                    <textarea name="<?php if ( isset( $meta_box['id'] ) ) echo esc_attr( $meta_box['id'] ); ?>" cols="40" rows="6"><?php if (  isset( $data[ $meta_box['id'] ] ) ) echo wp_kses_post( $data[ $meta_box['id'] ] ); else { if ( isset( $meta_box['std'] ) ) echo wp_kses_post(  $meta_box['std'] ); } ?></textarea>
                    <p><?php if ( isset( $meta_box['description'] ) ) echo wp_kses_post( $meta_box['description'] ); ?></p>
                </div>
			<?php }
            elseif ( $meta_box['type'] == 'select' ) { ?>
                <div>
                    <label for="<?php echo esc_attr( $meta_box['id'] ); ?>"><?php echo esc_attr( $meta_box['title'] ); ?></label>
                    <select name="<?php echo esc_attr( $meta_box['id'] ); ?>" id="<?php echo esc_attr( $meta_box['id'] ); ?>">
						<?php foreach ( $meta_box['options'] as $option ) { ?>
                            <option <?php if ( isset( $data[ $meta_box['id'] ] ) && ( $data[ $meta_box['id'] ] == $option ) ) { echo ' selected="selected"'; } elseif ( $option == $meta_box['std'] ) { echo ' selected="selected"'; } ?>><?php echo esc_attr( $option ); ?></option>
                        <?php } ?>
                    </select>
                    <p><?php if ( isset( $meta_box['description'] ) ) echo wp_kses_post( $meta_box['description'] ); ?></p>
                </div>
            <?php }
			elseif ( $meta_box['type'] == 'checkbox' ) { ?>
                <div>
					<?php if ( isset( $data[ $meta_box['id'] ] ) && $data[ $meta_box['id'] ] ){ $checked = 'checked="checked"'; } else { $checked = ''; } ?>
                    <label for="<?php echo esc_attr( $meta_box['id'] ); ?>"><input type="checkbox" name="<?php echo esc_attr( $meta_box['id'] ); ?>" id="<?php echo esc_attr( $meta_box['id'] ); ?>" value="true" <?php echo esc_html( $checked ); ?> /><?php echo esc_attr( $meta_box['title'] ); ?></label>
                    <p><?php if ( isset( $meta_box['description'] ) ) echo wp_kses_post( $meta_box['description'] ); ?></p>
                </div>
			<?php }
			elseif ( $meta_box['type'] == 'hr' ) {
				echo ('<div class="section-hr"></div>');
			}
        } ?>
	</div>
	<?php }

function newsplus_save_post_options( $post_id ) {
	global $post, $pls_post_options, $pls_post_key;
	$pls_post_options = apply_filters( 'pls_post_opts_array', $pls_post_options );
	$pls_post_key = apply_filters( 'pls_post_opts_key', $pls_post_key );

	// verify if this is an auto save routine.
	// If it is our form has not been submitted, so we dont want to do anything
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
		return;

	// verify this came from our screen and with proper authorization,
	// because save_post can be triggered at other times
	if ( isset( $_POST[ $pls_post_key . '_wpnonce' ] ) )
		if ( ! wp_verify_nonce( $_POST[ $pls_post_key . '_wpnonce' ], plugin_basename(__FILE__) ) )
			return;

	// Check permissions
	if ( isset( $_POST['post_type'] ) && 'page' == $_POST['post_type'] )
	{
		if ( ! current_user_can( 'edit_page', $post_id ) )
			return;
	}
	else
	{
		if ( ! current_user_can( 'edit_post', $post_id ) )
			return;
	}

	// OK, we're authenticated: we need to find and save the data
	foreach ( $pls_post_options as $meta_box ) {
		if ( isset( $meta_box['id'] ) && isset( $_POST[ $meta_box['id'] ] ) )
			$data[ $meta_box['id'] ] = $_POST[ $meta_box['id'] ];
	}

	if ( isset( $data ) )
		update_post_meta( $post_id, $pls_post_key, $data );
}
add_action( 'save_post', 'newsplus_save_post_options' ); ?>