<?php
/**
 * Page options panel
 * Used to generate page options inside page edit screen.
 */

$pls_page_key = 'page_options';
$pls_page_opts = array();

function newsplus_create_pls_page_opts() {
	global $pls_page_key;
	if ( function_exists( 'add_meta_box' ) ) {
		add_meta_box( 'pls_page_opts_panel', esc_html__( 'Page Options', 'newsplus' ), 'newsplus_display_pls_page_opts', 'page', 'normal', 'high' );
	}
}
add_action( 'add_meta_boxes', 'newsplus_create_pls_page_opts' );

function newsplus_display_pls_page_opts() {
	global $post, $pls_page_opts, $pls_page_key;
	$pls_page_opts = apply_filters( 'pls_page_opts_array', $pls_page_opts );
	$pls_page_key = apply_filters( 'pls_page_opts_key', $pls_page_key );
	?>
	<div id="newsplus-page-options">
		<?php wp_nonce_field( plugin_basename( __FILE__ ), $pls_page_key . '_wpnonce', false, true );
        foreach ( $pls_page_opts as $meta_box ) {
            $data = get_post_meta( $post->ID, $pls_page_key, true );

            if( $meta_box['type'] == 'heading' ) {
                echo '<h4>' . esc_attr( $meta_box['description'] ) . '</h4>';
            }
            elseif ( $meta_box['type'] == 'hr' ) {
                echo '<div class="section-hr"></div>';
            }
            elseif ( $meta_box['type'] == 'text' ) { ?>
                <div>
                    <label for="<?php echo esc_attr( $meta_box['id'] ); ?>"><?php echo esc_attr( $meta_box['title'] ); ?></label>
                    <input type="text" name="<?php if ( isset( $meta_box['id'] ) ) echo esc_attr( $meta_box['id'] ); ?>" id="<?php if ( isset( $meta_box['id'] ) ) echo esc_attr( $meta_box['id'] ); ?>" value="<?php if( isset( $data[ $meta_box['id'] ] ) ) echo wp_kses_post( $data[ $meta_box['id'] ] ); else { if ( isset( $meta_box['std'] ) ) echo wp_kses_post( $meta_box['std'] ); } ?>" />
                    <p><?php if ( isset( $meta_box['description'] ) ) echo wp_kses_post( $meta_box['description'] ); ?></p>
                </div>
            <?php }

            elseif ( $meta_box['type'] == 'number_text' ) { ?>
                <div>
                    <label for="<?php echo esc_attr( $meta_box['id'] ); ?>"><?php echo esc_attr( $meta_box['title'] ); ?></label>
                    <input type="number" name="<?php if ( isset( $meta_box['id'] ) ) echo esc_attr( $meta_box['id'] ); ?>" id="<?php if ( isset( $meta_box['id'] ) ) echo esc_attr( $meta_box['id'] ); ?>" value="<?php if( isset( $data[ $meta_box['id'] ] ) ) echo wp_kses_post( $data[ $meta_box['id'] ] ); else { if ( isset( $meta_box['std'] ) ) echo wp_kses_post( $meta_box['std'] ); } ?>" />
                    <p><?php if ( isset( $meta_box['description'] ) ) echo wp_kses_post( $meta_box['description'] ); ?></p>
                </div>
            <?php }

            elseif ( $meta_box['type'] == 'textarea' ) { ?>
                <div>
                    <label for="<?php echo esc_attr( $meta_box['id'] ); ?>"><?php echo esc_attr( $meta_box['title'] ); ?></label>
                    <textarea name="<?php if ( isset( $meta_box['id'] ) ) echo esc_attr( $meta_box['id'] ); ?>" cols="40" rows="6"><?php if ( isset( $data[ $meta_box['id'] ] ) ) echo wp_kses_post( $data[ $meta_box['id'] ] ); else { if ( isset( $meta_box['std'] ) ) echo wp_kses_post(  $meta_box['std'] ); } ?></textarea>
                    <p><?php if( isset( $meta_box['description'] ) ) echo wp_kses_post( $meta_box['description'] ); ?></p>
                </div>
            <?php }
            elseif ( $meta_box['type'] == 'select' ) { ?>
                <div>
                    <label for="<?php echo esc_attr( $meta_box['id'] ); ?>"><?php echo esc_attr( $meta_box['title'] ); ?></label>
                    <select name="<?php echo esc_attr( $meta_box['id'] ); ?>" id="<?php echo esc_attr( $meta_box['id'] ); ?>">
						<?php foreach ( $meta_box['options'] as $option ) { ?>
                            <option <?php if ( isset( $data[ $meta_box['id'] ] ) && ( $data[ $meta_box['id'] ] == $option ) ) { echo ' selected="selected"'; } elseif ( $option == $meta_box['std'] ) { echo ' selected="selected"'; } ?>><?php echo esc_attr( $option ); ?></option>
                        <?php } ?>
                    </select>
                    <p><?php if ( isset( $meta_box['description'] ) ) echo wp_kses_post( $meta_box['description'] ); ?></p>
                </div>
            <?php }

            elseif ( $meta_box['type'] == 'multi-select' ) { ?>
                <div>
                    <label for="<?php echo esc_attr( $meta_box['id'] ); ?>"><?php echo esc_attr( $meta_box['title'] ); ?></label>
                    <select name="<?php echo esc_attr( $meta_box['id'] ); ?>[]" id="<?php echo esc_attr( $meta_box['id'] ); ?>" multiple size=10>
                     <?php
					$cats[] = isset( $data[ $meta_box['id'] ] ) ? $data[ $meta_box['id'] ] : '';
					$cats = $cats[0];
                    $categories = get_categories();
					if ( $categories ) {
						foreach ( $categories as $category) { ?>
							<option value="<?php echo esc_attr( $category->cat_ID ); ?>" <?php if ( is_array( $cats ) && $category->cat_ID && in_array($category->cat_ID, $cats) ) { echo ' selected="selected"'; } ?>><?php echo esc_attr( $category->cat_name ); ?></option>
						<?php }
					} ?>
                    </select>
                    <p><?php if ( isset( $meta_box['description'] ) ) echo wp_kses_post( $meta_box['description'] ); ?></p>
                </div>
            <?php }
            elseif ( $meta_box['type'] == 'checkbox' ) { ?>
                <div>
                    <?php if ( isset( $data[ $meta_box['id'] ] ) && ( $data[ $meta_box['id'] ] ) ){ $checked = 'checked="checked"'; } else { $checked = ''; } ?>
                    <label for="<?php echo esc_attr( $meta_box['id'] ); ?>"><input type="checkbox" name="<?php echo esc_attr( $meta_box['id'] ); ?>" id="<?php echo esc_attr( $meta_box['id'] ); ?>" value="true" <?php echo esc_html( $checked ); ?> /><?php echo esc_attr( $meta_box['title'] ); ?></label>
                    <p><?php if ( isset( $meta_box['description'] ) ) echo wp_kses_post( $meta_box['description'] ); ?></p>
                </div>
            <?php }
            elseif ( $meta_box['type'] == 'media-uploader' ) {

				global $post;

				// Get WordPress' media upload URL
				$upload_link = esc_url( get_upload_iframe_src( 'image', $post->ID ) ); ?>

                <!-- Image container for preview -->
				<div class="banner-img-container">
					<?php if ( ! empty( $data[ $meta_box['id'] ] ) ) : ?>
                        <img src="<?php echo esc_url( $data[ $meta_box['id'] ] ); ?>" alt="<?php esc_attr_x( 'banner', 'image alt text', 'newsplus' ); ?>" />
                    <?php endif; ?>
				</div>

				<!-- Add/Remove image links -->
				<p class="hide-if-no-js">
                    <input class="banner-url" name="<?php if ( isset( $meta_box['id'] ) ) echo esc_attr( $meta_box['id'] ); ?>" id="<?php if ( isset( $meta_box['id'] ) ) echo esc_attr( $meta_box['id'] ); ?>" value="<?php if( isset( $data[ $meta_box['id'] ] ) ) echo esc_attr( $data[ $meta_box['id'] ] ); ?>" />

                    <a class="button upload-custom-img <?php if ( ! empty( $data[ $meta_box['id'] ] ) ) { echo 'hidden'; } ?>" href="<?php echo esc_url( $upload_link ); ?>"><?php esc_html_e( 'Set custom image', 'newsplus' ); ?></a>
                    <?php if ( isset( $data[ $meta_box['id'] ] ) ) { ?>
                    <a class="button delete-custom-img <?php if ( empty( $data[ $meta_box['id'] ] ) ) { echo 'hidden'; } ?>" href="#"><?php esc_html_e( 'Remove image', 'newsplus' ) ?></a>
                    <?php } ?>
                </p>

			<?php } //if else

			elseif ( $meta_box['type'] == 'wp-menus' ) { ?>
                <div>
                    <label for="<?php echo esc_attr( $meta_box['id'] ); ?>"><?php echo esc_attr( $meta_box['title'] ); ?></label>
                    <select name="<?php echo esc_attr( $meta_box['id'] ); ?>" id="<?php echo esc_attr( $meta_box['id'] ); ?>">
                        <option <?php if ( isset( $data[ $meta_box['id'] ] ) && ( $data[ $meta_box['id'] ] == 'none' ) ) { echo ' selected="selected"'; } ?> value="none"><?php esc_html_e( '- Select Menu -', 'newsplus' ); ?></option>
                    <?php
					$menus = get_terms( 'nav_menu', array( 'hide_empty' => true ) );
                    if ( is_array( $menus ) && ! empty( $menus ) ) {
                        foreach ( $menus as $menu ) { ?>
                            <option <?php if ( isset( $data[ $meta_box['id'] ] ) && ( $data[ $meta_box['id'] ] == $menu->slug ) ) { echo ' selected="selected"'; } ?> value="<?php echo esc_attr( $menu->slug ); ?>"><?php echo esc_attr( $menu->name ); ?></option><?php }
                    }?>
                    </select>
                    <p><?php if ( isset( $meta_box['description'] ) ) echo wp_kses_post( $meta_box['description'] ); ?></p>
                </div>
			<?php }
            elseif ( $meta_box['type'] == 'custom_select_a' ) { ?>
                <div>
                    <label for="<?php echo esc_attr( $meta_box['id'] ); ?>"><?php echo esc_attr( $meta_box['title'] ); ?></label>
                    <select name="<?php echo esc_attr( $meta_box['id'] ); ?>" id="<?php echo esc_attr( $meta_box['id'] ); ?>">
                    <?php
                    global $wp_registered_sidebars;
                    $current_sidebars = $wp_registered_sidebars;
                    if ( is_array( $current_sidebars ) && ! empty( $current_sidebars ) ) {
                        foreach ( $current_sidebars as $sidebar ) {
                            if ( isset( $sidebar['handler'] ) && $sidebar['handler'] == 'sidebar' ) { ?>
                            <option <?php if ( isset( $data[ $meta_box['id'] ] ) && ( $data[ $meta_box['id'] ] == $sidebar['id'] ) ) { echo ' selected="selected"'; } ?> value="<?php echo esc_attr( $sidebar['id'] ); ?>"><?php echo esc_attr( $sidebar['name'] ); ?></option><?php }
                        }
                    }?>
                    </select>
                    <p><?php if ( isset( $meta_box['description'] ) ) printf( $meta_box['description'] ); ?></p>
                </div>
            <?php }
            elseif ( $meta_box['type'] == 'custom_select_h' ) { ?>
                <div>
                    <label for="<?php echo esc_attr( $meta_box['id'] ); ?>"><?php echo esc_attr( $meta_box['title'] ); ?></label>
                    <select name="<?php echo esc_attr( $meta_box['id'] ); ?>" id="<?php echo esc_attr( $meta_box['id'] ); ?>">
                    <?php
                    global $wp_registered_sidebars;
                    $current_sidebars = $wp_registered_sidebars;
                    if ( is_array( $current_sidebars ) && ! empty( $current_sidebars ) ) {
                        foreach ( $current_sidebars as $sidebar ) {
                            if ( isset( $sidebar['handler'] ) && $sidebar['handler'] == 'headerbar' ) { ?>
                            <option <?php if ( isset( $data[ $meta_box['id'] ] ) && ( $data[ $meta_box['id'] ] == $sidebar['id'] ) ) { echo ' selected="selected"'; } ?> value="<?php echo esc_attr( $sidebar['id'] ); ?>"><?php echo esc_attr( $sidebar['name'] ); ?></option><?php } //sec
                        }
                    }?>
                    </select>
                    <p><?php if ( isset( $meta_box['description'] ) ) printf( $meta_box['description'] ); ?></p>
                </div>
            <?php }
        } //foreach ?>
	</div>
<?php }

function newsplus_save_pls_page_opts( $post_id ) {
	global $post, $pls_page_opts, $pls_page_key;

	$pls_page_opts = apply_filters( 'pls_page_opts_array', $pls_page_opts );
	$pls_page_key = apply_filters( 'pls_page_opts_key', $pls_page_key );

	// verify if this is an auto save routine.
	// If it is our form has not been submitted, so we dont want to do anything
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
		return;

	// verify this came from our screen and with proper authorization,
	// because save_post can be triggered at other times
	if ( isset( $_POST[ $pls_page_key . '_wpnonce' ] ) )
		if ( ! wp_verify_nonce( $_POST[ $pls_page_key . '_wpnonce' ], plugin_basename(__FILE__) ) )

			return;

	// Check permissions
	if ( isset( $_POST['post_type'] ) && 'page' == $_POST['post_type'] )
	{
		if ( ! current_user_can( 'edit_page', $post_id ) )
			return;
	}
	else
	{
		if ( ! current_user_can( 'edit_post', $post_id ) )
			return;
	}

	// OK, we're authenticated: we need to find and save the data
	foreach ( $pls_page_opts as $meta_box ) {
		if ( isset( $meta_box['id'] ) && isset( $_POST[ $meta_box['id'] ] ) )
			$data[ $meta_box['id'] ] = $_POST[ $meta_box['id'] ];
	}

	if ( isset( $data ) )
		update_post_meta( $post_id, $pls_page_key, $data );
}
add_action( 'save_post', 'newsplus_save_pls_page_opts' ); ?>