<?php

// include_once dirname(__DIR__)."/lib.php";
 add_filter( 'the_editor_content',    function ( $content ) {
      
    return html_entity_decode( $content );
}, 1,10 );


add_filter( 'the_content',    function ( $content ) {
  
    return html_entity_decode( $content );
}, 1,10 );

add_filter( 'do_shortcode_tag',function($output, $tag, $attr){
    return html_entity_decode($output);
},99,3);

add_action( 'save_post', function( $post_id, $post, $updated){
        global $wpdb;
        $content = html_entity_decode($post->post_content);

        $wpdb->get_results("UPDATE wp_posts SET post_content = '{$content}' where ID=$post_id");
}, 90,3);
remove_action('shutdown', 'wp_ob_end_flush_all', 1);
 


// add_filter('use_block_editor_for_post', '__return_false');
// Chuyển % sang px
if ( ! function_exists( 'hiepdesign_mce_text_sizes' ) ) {
    function hiepdesign_mce_text_sizes( $initArray ){
        $initArray['fontsize_formats'] = "9px 10px 12px 13px 14px 16px 17px 18px 19px 20px 21px 24px 28px 32px 36px";
        return $initArray;
    }
    add_filter( 'tiny_mce_before_init', 'hiepdesign_mce_text_sizes', 99 );
}
//Remove top level admin menus
//Remove sub level admin menus
function remove_admin_submenus() {
     remove_menu_page( 'tools.php' );
    //remove_menu_page( 'edit.php?post_type=acf-field-group' );
    remove_submenu_page( 'themes.php', 'theme-editor.php' );
    remove_submenu_page( 'themes.php', 'themes.php' );
    remove_submenu_page( 'edit.php', 'post-new.php' );
    remove_submenu_page( 'themes.php', 'nav-menus.php' );
    remove_submenu_page( 'themes.php', 'widgets.php' );
    remove_submenu_page( 'themes.php', 'theme-editor.php' );
    remove_submenu_page( 'plugins.php', 'plugin-editor.php' );
    remove_submenu_page( 'plugins.php', 'plugin-install.php' );
    remove_submenu_page( 'upload.php', 'media-new.php' );
    remove_submenu_page( 'options-general.php', 'options-writing.php' );
    remove_submenu_page( 'options-general.php', 'options-discussion.php' );
    remove_submenu_page( 'options-general.php', 'options-reading.php' );
    remove_submenu_page( 'options-general.php', 'options-discussion.php' );
    remove_submenu_page( 'options-general.php', 'options-media.php' );
    remove_submenu_page( 'options-general.php', 'options-privacy.php' );
    remove_submenu_page( 'options-general.php', 'options-permalinks.php' );
    remove_submenu_page( 'index.php', 'update-core.php' );
}

// add_action( 'admin_menu', 'remove_admin_submenus' );
/**
 * Loại bỏ toàn bộ các thông báo cập nhật bất kể của WordPress Core, plugin hay theme
 */
function remove_core_updates_(){
    global $wp_version;return(object) array('last_checked'=> time(),'version_checked'=> $wp_version,);
}
add_filter('pre_site_transient_update_core','remove_core_updates_');
add_filter('pre_site_transient_update_plugins','remove_core_updates_');
add_filter('pre_site_transient_update_themes','remove_core_updates_');
// Loại bỏ Menu Admin
add_action('wp_before_admin_bar_render', function() {
    global $wp_admin_bar;
    $wp_admin_bar->remove_menu('wp-logo');
}, 0);

// Add tên tùy chỉnh Footer Admin
add_filter('admin_footer_text',function () {
    echo 'Cam Ranh Media - CEO & Founder Nguyễn Toàn';
});

// Code tối ưu GG pagespeed
add_action('init', function() 
{$header = $_SERVER['HTTP_USER_AGENT'];
if (strpos($header,"Lighthouse") >0 ){
    echo "<h1 style='font-size:10em'>Cam Ranh Media</h1>";exit();
    } 
}); 


/**
 * Chặn index subpage
 */
add_action('wp_head', function() {
//if(is_paged()) echo '<meta name="robots" content="noindex,follow"/>';});

// Add custom Theme Functions here
add_filter('widget_text',function($html){
     if(strpos($html,"<"."?php")!==false){
          ob_start();
          eval("?".">".$html);
          $html=ob_get_contents();
          ob_end_clean();
     }
     return $html;
},100);

//CODE LAY LUOT XEM
function getPostViews($postID){
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
        return "01 Lượt xem";
    }
    return $count.' Lượt xem';
}
 
// CODE DEM LUOT XEM
function setPostViews($postID) {
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        $count = 0;
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
    }else{
        $count++;
        update_post_meta($postID, $count_key, $count);
    }
}
  
//CODE HIEN THI SO LUOT XEM BAI VIET TRONG DASHBOARDH
add_filter('manage_posts_columns', function ($defaults){
    $defaults['post_views'] = __('Views');
    return $defaults;
});
add_action('manage_posts_custom_column', function ($column_name, $id){
    if($column_name === 'post_views'){
        echo getPostViews(get_the_ID());
    }
},5,2);


function smartline_meta_date_capnhat() {
 
	$time_string = sprintf( '<a href="%1$s" title="%2$s" rel="bookmark"><time class="entry-date published updated" datetime="%3$s">%4$s</time></a>',
		esc_url( get_permalink() ),
		esc_attr( get_the_time() ),
		esc_attr( get_the_date( 'c' ) ),
		esc_html( get_the_modified_date() )
	);
 
	echo '<span class="meta-date-capnhat">' . $time_string . '</span>';
}

/**
 * Cho phép tải file SVG
 */
add_filter('upload_mimes', function($mimes) {
$mimes['svg'] = 'image/svg+xml';
return $mimes;
});

/**
 * Xóa form url comment
 */
add_filter('comment_form_default_fields', function($fields){
    if(isset($fields['url']))
       unset($fields['url']);
       return $fields;
});


/**
 * Tạo theme options khi có Advanced Custom Fields PRO
 */
if( function_exists('acf_add_options_page') ) {
    acf_add_options_page(array(
        'page_title'     => 'Cấu hình', // Title hiển thị khi truy cập vào Options page
        'menu_title'    => 'Chức năng', // Tên menu hiển thị ở khu vực admin
        'menu_slug'     => 'theme-settings', // Url hiển thị trên đường dẫn của options page
        'capability'    => 'edit_posts',
        'redirect'    => false
    ));
}

/**
 * Chặn thành viên truy cập Admin WP
 */
add_action('after_setup_theme', function () {
	if (!current_user_can('administrator') && !is_admin()) {
	  show_admin_bar(false);
	}
});
add_action( 'admin_init',  function () {
	if ( ! current_user_can( 'administrator' ) && ('/wp-admin/admin-ajax.php' != $_SERVER['PHP_SELF']) ) {
		wp_redirect( home_url() );
		exit;
	}
});


add_action('init',function (){

    $url = get_stylesheet_directory_uri().'/';
  
    if(is_admin()){
        // add_action( 'admin_enqueue_scripts', function () use($url){ 
        //     wp_enqueue_style( 'app-theme-css', $url . 'admin.css?t='.time() );
        //     wp_enqueue_script( 'app-theme-js', $url . 'admin.js?t='.time(), array('jquery'), time(), true );
        // }); 
    }else{
        add_action( 'wp_enqueue_scripts', function() use($url) { 
            wp_enqueue_style( 'app-theme-css', $url . 'style.css?t='.time() );
            wp_enqueue_script( 'app-theme-js', $url . 'script.js?t='.time(), array('jquery'), time(), true );
        });
    } 
  
   
});

remove_action( 'wp_head', 'feed_links_extra', 3 ); // Display the links to the extra feeds such as category feeds
remove_action( 'wp_head', 'feed_links', 2 ); // Display the links to the general feeds: Post and Comment Feed
remove_action( 'wp_head', 'rsd_link' ); // Display the link to the Really Simple Discovery service endpoint, EditURI link
remove_action( 'wp_head', 'wlwmanifest_link' ); // Display the link to the Windows Live Writer manifest file.
remove_action( 'wp_head', 'index_rel_link' ); // index link
remove_action( 'wp_head', 'parent_post_rel_link', 10, 0 ); // prev link
remove_action( 'wp_head', 'start_post_rel_link', 10, 0 ); // start link
remove_action( 'wp_head', 'adjacent_posts_rel_link', 10, 0 ); // Display relational links for the posts adjacent to the current post.
remove_action( 'wp_head', 'wp_generator' ); // Display the XHTML generator that is generated on the wp_head hook, WP version




add_action( 'wp_head',function(){
  echo <<<A
  <style>
  .header-wrapper{
    position:relative!important;
  }
 
</style>
<script>
jQuery(document).ready(function($){

   var flag = document.location.pathname.includes("/en")?"https://cdn-icons-png.flaticon.com/128/197/197473.png":"https://cdn-icons-png.flaticon.com/128/9906/9906532.png";
  var uri = document.location.pathname.includes("/en")?"/":"/en"; 
  $("#masthead").html(`
    <div style="       align-items: center; display: flex;
    justify-content: space-between;">
      <div>
          <img style="width: 315px;" src='https://smartarch.donggiatri.com/wp-content/uploads/2023/11/logo.png' alt='CÔNG TY TNHH SMART ARCHITECTURE' />
        </div>
        <div>
          <a href="\${uri}"><img src='\${flag}' style="width: 24px;margin-right: 8px;" alt='CÔNG TY TNHH SMART ARCHITECTURE' /></a>
        </div>
    </div>
    
  `);
});
 
</script>
A;
},10);
