<!--Header-->
<?php get_header();?>

<?php
        if ( function_exists('yoast_breadcrumb') ) {
        yoast_breadcrumb( '<div class="nhapho-breadcrumb" style="background: white;"><div class="row"><div class="col small-12 large-12" style="padding-bottom: 0;"><div class="col-inner"><p id="breadcrumbs" style="margin-bottom: 0em;padding: 10px;background: white;color: black;">','</p></div></div></div></div>' );
        }
    ?>

<div class="row">
	<div class="col small-12 large-12" style="padding-bottom: 0;">
		<div class="col-inner">
			
		</div>
	</div>
</div>

<div class="nhapho-content" itemscope="" itemtype="https://schema.org/CreativeWork" style="margin: 10px 0;">
	<div class="row">
    	<div class="col medium-7 small-12 large-7">
        	<div class="tieude col-inner">
				<?php setPostViews(get_the_ID()); ?>
            	<h1><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h1>
	            <div class="entry-meta" style="margin-bottom: 10px;">
	        		<span class="fa fa-eye" style="color: #837b7b;font-weight: 500;"><?php echo getPostViews(get_the_ID()); ?></span>
	        	</div><!-- .entry-meta -->
	            <div class="thong-tin-du-an">
	            	<div class="dia-chi">
						<p class="fa-map-marker"><strong>Địa chỉ: </strong><span><?php the_field('dia_chi'); ?></span></p>
					</div>
					<div class="phong-ngu">
						<p class="fa-bed"><span><strong>Phòng ngủ: </strong><?php the_field('phong_ngu'); ?></span></p>
					</div>
					<div class="phong-tam">
						<p class="fa-bath"><span><strong>Phòng tắm: </strong><?php the_field('phong_tam'); ?></span></p>
					</div>
					<div class="dien-tich">
						<p class="fa-arrows-alt"><span><strong>Diện tích: </strong><?php the_field('dien_tich'); ?></span></p>
					</div>
					<div class="gia">
						<strong>Giá bán: </strong><span style="color: red;font-size: 18px;"><strong><?php the_field('gia'); ?></strong></span>
					</div>
	          	</div>
      		</div>
    	</div>
        
    	<div class="col medium-5 small-12 large-5 small-col-first">
        	<div class="tieude col-inner">
				<div class="thong-tin-du-an">
                  
                  	<div class="div-right">
                      <div class="anh"><img src="<?php the_field('hinh_anh', 'option'); ?>"></div>
                      <div class="thong-tin-nguoi-ban">
                          <p class="ho-ten"><?php the_field('ho_va_ten', 'option'); ?></p>
                          <p class="mo-ta"><?php the_field('mo_ta', 'option'); ?></p>
                      </div>
                  	</div>
                  
                  	<div class="nut-lien-he" style="text-align: center;">
                      	<a class="zalo button" style="margin: 0;border-radius: 5px;" target="_blank" href="http://zalo.me/<?php the_field('zalo', 'option'); ?>">Chat Zalo</a>
                        <a class="hotline button pulse-shrink-on-hover" style="margin: 0;background: red;border-radius: 50px;" href="tel:<?php the_field('hotline', 'option'); ?>">Hotline: <?php the_field('hotline', 'option'); ?></a>
                    </div>
                  
                </div>
        	</div>
    	</div>
	</div>
  
    <div class="row">
    	<div class="col small-12 large-12">
       		<div class="tieude col-inner">
        		<div class="content-single-post">
                	<div class="post-content">
                      <h2>Mô tả</h2>
                		<div class="entry-content" itemprop="text">
                	    	<?php the_content(); ?>
                		</div><!-- .entry-content -->
                	</div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col small-12 large-12">
            <div class="tieude col-inner">
                <!----Bình-Luận------>
                <div class="comments-area post-content">
                    <?php comments_template(); ?>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="row">
	<div class="col small-12 large-12">
		<div class="col-inner">
<?php
$postType = 'chung-cu';
$taxonomyName = 'khu_vuc';
$taxonomy = get_the_terms(get_the_ID(), $taxonomyName);
if ($taxonomy){
   echo '<div class="relatedcat">';
   $category_ids = array();
   foreach($taxonomy as $individual_category) $category_ids[] = $individual_category->term_id;
   $args = array( 
      'post_type' =>  $postType,
      'post__not_in' => array(get_the_ID()),
      'posts_per_page' => 3,
      'tax_query' => array(
         array(
            'taxonomy' => $taxonomyName,
            'field'    => 'term_id',
            'terms'    => $category_ids,
         ),
      )
   );
   $my_query = new wp_query($args);
   if( $my_query->have_posts() ):
      echo '<h3>Chung cư liên quan:</h3><div class="nhapho row large-columns-3 medium-columns- small-columns-1">';
      while ($my_query->have_posts()):$my_query->the_post();
         echo '
         <div class="col post-item"><div class="chitiet">
			<div class="nhapho-image">
				<figure class="photo"><img src="'.get_the_post_thumbnail_url().'" alt="'.get_the_title().'">
					<figcaption>
					<h3><span>'.get_field('tinh_trang').'</span></h3>
					</figcaption>
					<a href="'.get_the_permalink().'" title="'.get_the_title().'"></a>
				</figure>
             </div>
			<h4 class="nhapho-h2"><a href="'.get_the_permalink().'" title="'.get_the_title().'">'.get_the_title().'</a></h4>
            <div class="thong-tin-du-an">
              <div class="dia-chi">
                  <p class="fa-map-marker"><span><strong>Địa chỉ: </strong>'.get_field('dia_chi').'</span></p>
              </div>
              <div class="phong-ngu">
                  <p class="fa-bed"><span><strong>Phòng ngủ: </strong>'.get_field('phong_ngu').'</span></p>
              </div>
              <div class="phong-tam">
                  <p class="fa-bath"><span><strong>Phòng tắm: </strong>'.get_field('phong_tam').'</span></p>
              </div>
              <div class="dien-tich">
                  <p class="fa-arrows-alt"><span><strong>Diện tích: </strong>'.get_field('dien_tich').'</span></p>
              </div>
              <div class="xem">
                  <div class="gia">
                      <span style="color: red;font-size: 18px;"><strong>'.get_field('gia').'</strong></span>
                  </div>
                  <div class="xem-ngay">
                      <a href="'.get_the_permalink().'" class="button">Xem ngay</a>
                  </div>
              </div>
            </div>
            </div>
           </div>
         ';
      endwhile;
      echo '</div>';
   endif; wp_reset_query();
   echo '</div>';
}?>
		</div>
	</div>
</div>
        


							
<!--Footer-->
<?php get_footer();?>

<style>
  .tieude{
    padding: 30px 20px;
    border-radius: 8px;
    box-shadow: 0 0 26px 0 rgb(22 73 172 / 12%);
    overflow: hidden;
    background: white;
  }

  .chitiet{
    border: 1px solid #eef1fd;
    -webkit-box-shadow: 0 1px 1px rgb(0 0 0 / 4%);
    -ms-box-shadow: 0 1px 1px rgba(0,0,0,.04);
    box-shadow: 0 1px 1px rgb(0 0 0 / 4%);
    background: white;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 10px 10px 10px -5px rgb(218 216 230);
    /*transition: all 0.5s ease-in-out 0s;*/
}

.chitiet:hover{
    box-shadow: 0px 0px 35px 0px rgb(45 192 248 / 30%);
    transition: all 0.2s ease-in-out 0s;
}

.nhapho-image{text-align: center;}

.chitiet .nhapho-h2{font-size:20px;margin: 0;font-weight: bold;padding: 0 7px 0 7px;margin-top: 10px;}

.chitiet .thong-tin-du-an p{margin-bottom: 0;line-height: 2;}
	
.chitiet .thong-tin-du-an .xem{display: flex;}
.chitiet .thong-tin-du-an .gia{width:50%;display: flex;justify-content: center;align-items: center;}
.chitiet .thong-tin-du-an .xem-ngay{width:50%;text-align: center;}
.chitiet .thong-tin-du-an .button{
	margin: 0;
    background: white;
    border: 1px dashed #036ffb;
    color: #036ffb;
}
	
.chitiet .thong-tin-du-an .button:hover{
	margin: 0;
    background: #036ffb;
    border: 0px dashed #036ffb;
    color: white;
}
  
.div-right {
    display: block;
    font-size: 14px;
    color: #5f5f5f;
    margin-top: 0;
    margin-bottom: 15px;
  	text-align: center;
}
  
.div-right img {
    display: inline-block;
    width: 115px;
    object-position: center;
    object-fit: cover;
    border-radius: 99%;
    border: 1px solid #ececec;
    padding: 5px;
}
  
.thong-tin-nguoi-ban {
    display: inline-block;
    vertical-align: middle;
}
  
.thong-tin-nguoi-ban .ho-ten {
    line-height: 30px;
    color: #3d4d65;
    font-size: 25px;
    margin-bottom: 5px;
    display: block;
}
  
.thong-tin-nguoi-ban .mo-ta {
    color: #3d4d65;
    margin-bottom: 5px;
    font-size: 16px;
}
/* CSS Mobile */
@media all and (max-width: 480px) {
 
}
 
/* CSS Desktop */
@media all and (max-width: 1024px) {
 
}
</style>