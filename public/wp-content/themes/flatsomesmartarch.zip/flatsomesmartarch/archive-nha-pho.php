<?php get_header();?>

<section class="nha-pho">
    <?php
        if ( function_exists('yoast_breadcrumb') ) {
        yoast_breadcrumb( '<div class="nhapho-breadcrumb" style="background: white;"><div class="row"><div class="col small-12 large-12" style="padding-bottom: 0;"><div class="col-inner"><p id="breadcrumbs" style="margin-bottom: 0em;padding: 10px;background: white;color: black;">','</p></div></div></div></div>' );
        }
    ?>

<div class="nhapho-content" style="margin: 10px 0;">
	<div class="grid-container">
		<div class="row">
			<div class="col small-12 large-12" style="padding-bottom: 0;">
				<div class="col-inner">
					
				</div>
			</div>
		</div>
			
		<div class="row">
			<div class="col small-12 large-12" style="padding-bottom: 0;">
				<div class="col-inner">
					<h1 class="entry-title" itemprop="name headline" style="margin: 10px 0;border-bottom: 2px solid #036ffb;"><span style="background: #036ffb;color: white;padding: 2px 10px;"><?php wp_title(''); ?></span></h1>
				</div>
			</div>
                <!--Hiển thị bài viết chuyên mục-->
                <?php 
                  $args = array(
                    'post_status' => 'publish',
                    'posts_per_page' => -1,
                    'post_type'      => 'nha-pho'
                  );
                  $the_query = new WP_Query( $args );
                ?>
                <?php if( $the_query->have_posts() ): ?>
                
                <div class="nhapho row large-columns-3 medium-columns- small-columns-1" style="margin: 0;">
                <?php while( $the_query->have_posts() ) : $the_query->the_post(); ?>
                    <div class="col post-item" style="margin-bottom:25px;">
                        <div class="col-inner">
                            <!--Hiển thị hình ảnh bài viết-->
							<div class="nhapho-image">
								<figure class="photo"><?php echo the_post_thumbnail() ?>
									<figcaption>
									<h3><span><?php the_field('tinh_trang'); ?></span></h3>
									</figcaption>
									<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"></a>
								</figure>
                            </div>        
                            <!--Hiển thị tiêu đề bài viết-->                        
                            <h2 class="nhapho-h2"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
                            
							<div class="thong-tin-du-an">
								<div class="dia-chi">
									<p class="fa-map-marker"><strong>Địa chỉ: </strong><span><?php the_field('dia_chi'); ?></span></p>
								</div>
								<div class="phong-ngu">
									<p class="fa-bed"><span><strong>Phòng ngủ: </strong><?php the_field('phong_ngu'); ?></span></p>
								</div>
								<div class="phong-tam">
									<p class="fa-bath"><span><strong>Phòng tắm: </strong><?php the_field('phong_tam'); ?></span></p>
								</div>
								<div class="dien-tich">
									<p class="fa-arrows-alt"><span><strong>Diện tích: </strong><?php the_field('dien_tich'); ?></span></p>
								</div>
								<div class="xem">
									<div class="gia">
										<span style="color: red;font-size: 18px;"><strong><?php the_field('gia'); ?></strong></span>
									</div>
									<div class="xem-ngay">
									<a href="<?php the_permalink() ?>" class="button">Xem ngay</a>
									</div>
								</div>
							</div>
                            <!--<div class="excerpt">
                                <p><a href="<?php the_permalink() ?>">
                                <?php
                                    $excerpt = get_the_excerpt();
                                    $excerpt = substr($excerpt, 0, 260);
                                    $result = substr($excerpt, 0, strrpos($excerpt, ' '));
                                    echo $result;
                                    ?></a>
                                </p>
                            </div>-->
                        </div>
                    </div>
                <?php endwhile; ?>
                </div>
                <?php endif; ?>
                <?php wp_reset_query(); ?>
                <!--End Hiển thị bài viết chuyên mục-->
            </div>

        </div>
    </div>
</section><!--End-->



<!--Footer-->
<?php get_footer(); ?>

<style>
.nhapho .col-inner{
    border: 1px solid #eef1fd;
    -webkit-box-shadow: 0 1px 1px rgb(0 0 0 / 4%);
    -ms-box-shadow: 0 1px 1px rgba(0,0,0,.04);
    box-shadow: 0 1px 1px rgb(0 0 0 / 4%);
    background: white;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 10px 10px 10px -5px rgb(218 216 230);
    /*transition: all 0.5s ease-in-out 0s;*/
}

.nhapho .col-inner:hover{
    box-shadow: 0px 0px 35px 0px rgb(45 192 248 / 30%);
    transition: all 0.2s ease-in-out 0s;
}

.nhapho-image{text-align: center;}

.nhapho-h2{font-size:20px;margin: 0;font-weight: bold;padding: 0 7px 0 7px;margin-top: 10px;}

.excerpt p{
    color: black;
    font-size: 16px;
    margin: 0;
	padding: 0 7px 0 7px;
}

.thong-tin-du-an p{margin-bottom: 0;line-height: 2;}
	
.thong-tin-du-an .xem{display: flex;}
.thong-tin-du-an .gia{width:50%;display: flex;justify-content: center;align-items: center;}
.thong-tin-du-an .xem-ngay{width:50%;text-align: center;}
.thong-tin-du-an .button{
	margin: 0;
    background: white;
    border: 1px dashed #036ffb;
    color: #036ffb;
}
	
.thong-tin-du-an .button:hover{
	margin: 0;
    background: #036ffb;
    border: 0px dashed #036ffb;
    color: white;
}

/* CSS Mobile */
@media all and (max-width: 480px) {
 
}
 
/* CSS Desktop */
@media all and (max-width: 1024px) {
 .col-1 #text-3{display:none;}
}

/* CSS Ipad */
@media all and (max-width: 768px) {

}
</style>