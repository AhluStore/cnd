<?php get_header();?>
<?php /* Template Name: Page Trang chủ */ ?>
<?php the_content(); ?>
<section class="nha-pho">
<div class="nhapho-content" style="margin: 10px 0;">
    <div class="grid-container">
        <div class="row">
            <div class="col small-12 large-12" style="padding-bottom: 0;">
                <div class="col-inner">
                    
                </div>
            </div>
        </div>
            
        <div class="row">
            <div class="col small-12 large-12" style="padding-bottom: 0;">
                <div class="col-inner">
                  <div class="module-title">
                    <h2 class="entry-title" itemprop="name headline" style="margin: 10px 0;border-bottom: 2px solid #036ffb;"><span style="background: #036ffb;color: white;padding: 2px 10px;"><?php the_field('title_biet_thu', 'option'); ?></span></h2>
                  </div>
                </div>
            </div>
                <!--Hiển thị bài viết chuyên mục-->
                <?php 
                  $args = array(
                    'post_status' => 'publish',
                    'posts_per_page' => -1,
                    'post_type'      => get_field('nd_biet_thu', 'option')
                  );
                  $the_query = new WP_Query( $args );
                ?>
                <?php if( $the_query->have_posts() ): ?>
                
                <div class="nhapho row large-columns-3 medium-columns- small-columns-1" style="margin: 0;">
                <?php while( $the_query->have_posts() ) : $the_query->the_post(); ?>
                    <div class="col post-item" style="margin-bottom:25px;">
                        <div class="col-inner">
                            <!--Hiển thị hình ảnh bài viết-->
                            <div class="nhapho-image">
								<figure class="photo"><?php echo the_post_thumbnail() ?>
									<figcaption>
									<h3><span><?php the_field('tinh_trang'); ?></span></h3>
									</figcaption>
									<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"></a>
								</figure>
                            </div>         
                            <!--Hiển thị tiêu đề bài viết-->                        
                            <h2 class="nhapho-h2"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
                            
                            <div class="thong-tin-du-an">
                                <div class="dia-chi">
                                    <p class="fa-map-marker"><strong>Địa chỉ: </strong><span><?php the_field('dia_chi'); ?></span></p>
                                </div>
                                <div class="phong-ngu">
                                    <p class="fa-bed"><span><strong>Phòng ngủ: </strong><?php the_field('phong_ngu'); ?></span></p>
                                </div>
                                <div class="phong-tam">
                                    <p class="fa-bath"><span><strong>Phòng tắm: </strong><?php the_field('phong_tam'); ?></span></p>
                                </div>
                                <div class="dien-tich">
                                    <p class="fa-arrows-alt"><span><strong>Diện tích: </strong><?php the_field('dien_tich'); ?></span></p>
                                </div>
                                <div class="xem">
                                    <div class="gia">
                                        <span style="color: red;font-size: 18px;"><strong><?php the_field('gia'); ?></strong></span>
                                    </div>
                                    <div class="xem-ngay">
                                    <a href="<?php the_permalink() ?>" class="button">Xem ngay</a>
                                    </div>
                                </div>
                            </div>
                            <!--<div class="excerpt">
                                <p><a href="<?php the_permalink() ?>">
                                <?php
                                    $excerpt = get_the_excerpt();
                                    $excerpt = substr($excerpt, 0, 260);
                                    $result = substr($excerpt, 0, strrpos($excerpt, ' '));
                                    echo $result;
                                    ?></a>
                                </p>
                            </div>-->
                        </div>
                    </div>
                <?php endwhile; ?>
                </div>
                <?php endif; ?>
                <?php wp_reset_query(); ?>
                <!--End Hiển thị bài viết chuyên mục-->
            </div>

                    <div class="row">
            <div class="col small-12 large-12" style="padding-bottom: 0;">
                <div class="col-inner">
                    <h2 class="entry-title" itemprop="name headline" style="margin: 10px 0;border-bottom: 2px solid #036ffb;"><span style="background: #036ffb;color: white;padding: 2px 10px;"><?php the_field('title_chung_cu', 'option'); ?></span></h2>
                </div>
            </div>
                <!--Hiển thị bài viết chuyên mục-->
                <?php 
                  $args = array(
                    'post_status' => 'publish',
                    'posts_per_page' => -1,
                    'post_type'      => get_field('nd_chung_cu', 'option')
                  );
                  $the_query = new WP_Query( $args );
                ?>
                <?php if( $the_query->have_posts() ): ?>
                
                <div class="nhapho row large-columns-3 medium-columns- small-columns-1" style="margin: 0;">
                <?php while( $the_query->have_posts() ) : $the_query->the_post(); ?>
                    <div class="col post-item" style="margin-bottom:25px;">
                        <div class="col-inner">
                            <!--Hiển thị hình ảnh bài viết-->
                            <div class="nhapho-image">
								<figure class="photo"><?php echo the_post_thumbnail() ?>
									<figcaption>
									<h3><span><?php the_field('tinh_trang'); ?></span></h3>
									</figcaption>
									<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"></a>
								</figure>
                            </div>         
                            <!--Hiển thị tiêu đề bài viết-->                        
                            <h2 class="nhapho-h2"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
                            
                            <div class="thong-tin-du-an">
                                <div class="dia-chi">
                                    <p class="fa-map-marker"><strong>Địa chỉ: </strong><span><?php the_field('dia_chi'); ?></span></p>
                                </div>
                                <div class="phong-ngu">
                                    <p class="fa-bed"><span><strong>Phòng ngủ: </strong><?php the_field('phong_ngu'); ?></span></p>
                                </div>
                                <div class="phong-tam">
                                    <p class="fa-bath"><span><strong>Phòng tắm: </strong><?php the_field('phong_tam'); ?></span></p>
                                </div>
                                <div class="dien-tich">
                                    <p class="fa-arrows-alt"><span><strong>Diện tích: </strong><?php the_field('dien_tich'); ?></span></p>
                                </div>
                                <div class="xem">
                                    <div class="gia">
                                        <span style="color: red;font-size: 18px;"><strong><?php the_field('gia'); ?></strong></span>
                                    </div>
                                    <div class="xem-ngay">
                                    <a href="<?php the_permalink() ?>" class="button">Xem ngay</a>
                                    </div>
                                </div>
                            </div>
                            <!--<div class="excerpt">
                                <p><a href="<?php the_permalink() ?>">
                                <?php
                                    $excerpt = get_the_excerpt();
                                    $excerpt = substr($excerpt, 0, 260);
                                    $result = substr($excerpt, 0, strrpos($excerpt, ' '));
                                    echo $result;
                                    ?></a>
                                </p>
                            </div>-->
                        </div>
                    </div>
                <?php endwhile; ?>
                </div>
                <?php endif; ?>
                <?php wp_reset_query(); ?>
                <!--End Hiển thị bài viết chuyên mục-->
            </div>

                    <div class="row">
            <div class="col small-12 large-12" style="padding-bottom: 0;">
                <div class="col-inner">
                    <h2 class="entry-title" itemprop="name headline" style="margin: 10px 0;border-bottom: 2px solid #036ffb;"><span style="background: #036ffb;color: white;padding: 2px 10px;"><?php the_field('title_nha_pho', 'option'); ?></span></h2>
                </div>
            </div>
                <!--Hiển thị bài viết chuyên mục-->
                <?php 
                  $args = array(
                    'post_status' => 'publish',
                    'posts_per_page' => -1,
                    'post_type'      => get_field('nd_nha_pho', 'option')
                  );
                  $the_query = new WP_Query( $args );
                ?>
                <?php if( $the_query->have_posts() ): ?>
                
                <div class="nhapho row large-columns-3 medium-columns- small-columns-1" style="margin: 0;">
                <?php while( $the_query->have_posts() ) : $the_query->the_post(); ?>
                    <div class="col post-item" style="margin-bottom:25px;">
                        <div class="col-inner">
                            <!--Hiển thị hình ảnh bài viết-->
                            <div class="nhapho-image">
								<figure class="photo"><?php echo the_post_thumbnail() ?>
									<figcaption>
									<h3><span><?php the_field('tinh_trang'); ?></span></h3>
									</figcaption>
									<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"></a>
								</figure>
                            </div>        
                            <!--Hiển thị tiêu đề bài viết-->                        
                            <h2 class="nhapho-h2"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
                            
                            <div class="thong-tin-du-an">
                                <div class="dia-chi">
                                    <p class="fa-map-marker"><strong>Địa chỉ: </strong><span><?php the_field('dia_chi'); ?></span></p>
                                </div>
                                <div class="phong-ngu">
                                    <p class="fa-bed"><span><strong>Phòng ngủ: </strong><?php the_field('phong_ngu'); ?></span></p>
                                </div>
                                <div class="phong-tam">
                                    <p class="fa-bath"><span><strong>Phòng tắm: </strong><?php the_field('phong_tam'); ?></span></p>
                                </div>
                                <div class="dien-tich">
                                    <p class="fa-arrows-alt"><span><strong>Diện tích: </strong><?php the_field('dien_tich'); ?></span></p>
                                </div>
                                <div class="xem">
                                    <div class="gia">
                                        <span style="color: red;font-size: 18px;"><strong><?php the_field('gia'); ?></strong></span>
                                    </div>
                                    <div class="xem-ngay">
                                    <a href="<?php the_permalink() ?>" class="button">Xem ngay</a>
                                    </div>
                                </div>
                            </div>
                            <!--<div class="excerpt">
                                <p><a href="<?php the_permalink() ?>">
                                <?php
                                    $excerpt = get_the_excerpt();
                                    $excerpt = substr($excerpt, 0, 260);
                                    $result = substr($excerpt, 0, strrpos($excerpt, ' '));
                                    echo $result;
                                    ?></a>
                                </p>
                            </div>-->
                        </div>
                    </div>
                <?php endwhile; ?>
                </div>
                <?php endif; ?>
                <?php wp_reset_query(); ?>
                <!--End Hiển thị bài viết chuyên mục-->
            </div>

        </div>
    </div>
</section><!--End-->

<!--Blog-->
<div class="tin-tuc" style="padding-top: 20px;background: url(https://ketoankhanhhoa.com/wp-content/uploads/2020/10/home-gt-1.png) left bottom no-repeat,url(https://ketoankhanhhoa.com/wp-content/uploads/2020/10/home-gt-2.png) right bottom no-repeat #f4f8f9;">
	<div class="row">
		<div class="subcat" style="background: #efefef;">
			<h2 class="title-section" style="margin-bottom: 0;">
				<span class="heading-icon" style="background-color: #036ffb;line-height: 40px;color: #fff;display: inline-block;padding: 0 10px;-webkit-border-radius: 3px;-moz-border-radius: 3px;border-radius: 3px;margin-top: 0px;">Tin dự án</span>
			</h2>
		</div>
	</div>
<?php echo do_shortcode('[section label="Blog"][row][col span__sm="12"][blog_posts style="default" columns="3" columns__md="2" animate="fadeInRight" slider_nav_style="simple" cat="1" show_date="false" excerpt="false" comments="false" image_radius="2" image_hover="color" text_hover="bounce"][/col][/row][/section]'); ?>
</div>
  


<!--Footer-->
<?php get_footer();?>

<style>
.nhapho .col-inner{
    border: 1px solid #eef1fd;
    -webkit-box-shadow: 0 1px 1px rgb(0 0 0 / 4%);
    -ms-box-shadow: 0 1px 1px rgba(0,0,0,.04);
    box-shadow: 0 1px 1px rgb(0 0 0 / 4%);
    background: white;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 10px 10px 10px -5px rgb(218 216 230);
    /*transition: all 0.5s ease-in-out 0s;*/
}

.nhapho .col-inner:hover{
    box-shadow: 0px 0px 35px 0px rgb(45 192 248 / 30%);
    transition: all 0.2s ease-in-out 0s;
}

.nhapho-image{text-align: center;}

.nhapho-h2{font-size:20px;margin: 0;font-weight: bold;padding: 0 7px 0 7px;margin-top: 10px;}

.excerpt p{
    color: black;
    font-size: 16px;
    margin: 0;
    padding: 0 7px 0 7px;
}

.thong-tin-du-an p{margin-bottom: 0;line-height: 2;}
    
.thong-tin-du-an .xem{display: flex;}
.thong-tin-du-an .gia{width:50%;display: flex;justify-content: center;align-items: center;}
.thong-tin-du-an .xem-ngay{width:50%;text-align: center;}
.thong-tin-du-an .button{
    margin: 0;
    background: white;
    border: 1px dashed #036ffb;
    color: #036ffb;
}
    
.thong-tin-du-an .button:hover{
    margin: 0;
    background: #036ffb;
    border: 0px dashed #036ffb;
    color: white;
}
    
.col-1 .widget-title, .col-3 .widget-title {
    color: black;
    border-width: 0 0 0 3px;
    border-style: solid;
    border-color: #0ea449;
    letter-spacing: 1px;
    font-size: 16px;
    padding-left: 10px;
    line-height: 1;
    text-transform: uppercase;
}

.col-1 .textwidget p{
    color:black;
    font-size:16px;
}

.col-1 #text-3{
    border: 1px solid #eef1fd;
    -webkit-box-shadow: 0 1px 1px rgb(0 0 0 / 4%);
    -ms-box-shadow: 0 1px 1px rgba(0,0,0,.04);
    box-shadow: 0 1px 1px rgb(0 0 0 / 4%);
    background: white;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 10px 10px 10px -5px rgb(218 216 230);
    transition: all 0.5s ease-in-out 0s;
}

.col-3 .widget ul li:before{content:"\f14b";}

.col-3 #recent-posts-2{
    background: white;
    padding: 10px;
}

.col-3 .widget ul li:before{
    font-family:FontAwesome;
}

.nhapho-login .button:hover{
    box-shadow:0 3px 10px rgb(10 37 64 / 38%);
    transition:box-shadow .5s;
}

.entry-title:after {
    content: ' ';
    background: #036ffb;
    display: block;
    width: 2rem;
    height: 100%;
    position: absolute;
    z-index: -1;
    right: -0.9375rem;
    bottom: -1px;
    transform: skewX(40deg);
}
	
.tin-tuc .box-text {
    border: 1px solid #eef1fd;
    -webkit-box-shadow: 0 1px 1px rgb(0 0 0 / 4%);
    -ms-box-shadow: 0 1px 1px rgba(0,0,0,.04);
    box-shadow: 0 1px 1px rgb(0 0 0 / 4%);
    background: white;
    padding: 20px;
}
	

/* CSS Mobile */
@media all and (max-width: 480px) {
 
}
 
/* CSS Desktop */
@media all and (max-width: 1024px) {
 .col-1 #text-3{display:none;}
}

/* CSS Ipad */
@media all and (max-width: 768px) {

}
</style>