<?php

/**
 * Careerfy Theme Config.
 *
 * @package Careerfy
 */
define("CAREERFY_VERSION", "3.4.0");
define("WP_JOBSEARCH_VERSION", "1.4.6");

function careerfy_framework_options() {
    global $careerfy_framework_options;
    return $careerfy_framework_options;
}
