<?php
/**
 * Template Name: Portfolio 3 columns
 */

get_header(); ?>

<div class="clearfix">
  <div class="grid_24">
  	<div class="holder clearfix">
    	<div class="fleft">
      	<div id="categorybox">
          <ul class="menu">
            <li><a href="#">categories</a>
                <?php
								//list terms in a given taxonomy (useful as a widget for twentyten)
								$taxonomy = 'portfolio_category';
								$tax_terms = get_terms($taxonomy);
								?>
								<ul class="submenu" id="sm_1">
								<?php
								foreach ($tax_terms as $tax_term) {
								echo '<li>' . '<a href="' . esc_attr(get_term_link($tax_term, $taxonomy)) . '" title="' . sprintf( __( "View all posts in %s" ), $tax_term->name ) . '" ' . '>' . $tax_term->name.'</a></li>';
								}
								?>
								</ul>
            </li>
          </ul>
        </div>
      </div>
			<div class="fright">
				<?php if ( ! dynamic_sidebar( 'Before Content Area' ) ) : ?>
			    <!--Widgetized 'Before Content Area' for the home page-->
			  <?php endif ?>
       </div>
    </div>
  </div>
</div>

<div id="content" class="grid_18">

<div id="gallery">
  <ul class="portfolio">
  	<?php
			$i=1;
      if ( get_query_var('paged') ) {
              $paged = get_query_var('paged');
      } elseif ( get_query_var('page') ) {
              $paged = get_query_var('page');
      } else {
              $paged = 1;
      }
      $values     = get_post_custom_values( 'category-include' );
      $cat        = $values[0];
      query_posts( array(
        'post_type'          => 'portfolio',
        'portfolio_category' => $cat,
        'posts_per_page'     => 12,
        'paged'              => $paged,
        )
      );
      if ( have_posts() ) : $count = 0; while ( have_posts() ) : the_post(); $count++;
			if(($i%3) == 0){ $addclass = "nomargin";	}
      ?>
    <?php


    ?>

      <li class="<?php echo $addclass; ?>">
      	<header class="f-item-head">
        	<div class="fleft"><?php if(function_exists('the_ratings')) { the_ratings(); } ?></div>
          <div class="fright"><?php comments_popup_link('0', '1', '%', 'comments-link', '-'); ?></div>
        </header>
        <div class="folio-desc">
          <h4><a href="<?php the_permalink(); ?>"><?php $title = the_title('','',FALSE); echo substr($title, 0, 40); ?></a></h4>
          <time datetime="<?php the_time('Y-m-d\TH:i'); ?>"><?php the_time('m.d.Y'); ?></time>
        </div>
				<span class="image-border"><a class="image-wrap" href="<?php the_permalink() ?>" title="<?php _e('Permanent Link to', 'theme1418');?> <?php the_title_attribute(); ?>" ><?php the_post_thumbnail( 'portfolio-post-thumbnail' ); ?></a></span>
      </li>


    <?php $i++; $addclass = ""; endwhile; else: ?>
    <div class="no-results">
      <p><strong>There has been an error.</strong></p>
      <p>We apologize for any inconvenience, please <a href="<?php bloginfo('url'); ?>/" title="<?php bloginfo('description'); ?>">return to the home page</a> or use the search form below.</p>
      <?php get_search_form(); ?> <!-- outputs the default Wordpress search form-->
    </div><!--noResults-->
  <?php endif; ?>
  </ul>
  <div class="clear"></div>
</div>





<?php if(function_exists('wp_pagenavi')) : ?>
	<div class="wrapper"><?php wp_pagenavi(); ?></div>
<?php else : ?>
  <?php if ( $wp_query->max_num_pages > 1 ) : ?>
    <nav class="oldernewer">
      <div class="older">
        <?php next_posts_link('&laquo; Older Entries') ?>
      </div><!--.older-->
      <div class="newer">
        <?php previous_posts_link('Newer Entries &raquo;') ?>
      </div><!--.newer-->
    </nav><!--.oldernewer-->
  <?php endif; ?>
<?php endif; ?>
<!-- Page navigation -->

<?php
  // Reset Query
  wp_reset_query();
?>


</div><!-- #content -->
<aside class="grid_6">
	<?php if ( ! dynamic_sidebar( 'Home Sidebar' ) ) : ?>
    <!--Widgetized 'Home Sidebar' for the home page-->
  <?php endif ?>
</aside>


<?php get_footer(); ?>