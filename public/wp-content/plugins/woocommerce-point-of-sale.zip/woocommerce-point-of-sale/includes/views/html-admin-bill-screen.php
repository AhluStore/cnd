<?php
require_once( ABSPATH . 'wp-admin/includes/class-wp-screen.php' );
require_once( ABSPATH . 'wp-admin/includes/screen.php' );
include_once( dirname(WC_PLUGIN_FILE) . '/includes/admin/wc-admin-functions.php' );

do_action( 'admin_print_styles' );
do_action( 'admin_print_scripts' );
?>
<div class="content">

</div>
