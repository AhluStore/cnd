<?php
/**
 * HTML for a view registers page in admin.
 *
 * @author   Actuality Extensions
 * @package  WoocommercePointOfSale/views
 * @since    0.1
 */
global $wpdb;
$admin_url = admin_url();
// (get_current_blog_id(), '/');
// if (isset($_SERVER['HTTP_REFERER'])) {
//     $ref = $_SERVER['HTTP_REFERER'];
//     if (!empty($_SERVER['HTTPS']) && !empty($ref) && strpos($ref, 'https://') === false) {
//         $admin_url = str_replace('https://', 'http://', $admin_url);
//     }
// }
// print_r($data);
// die();

//try to get api key wc api
// $id = get_current_user_id();
// $key = $wpdb->get_results("select * from wp_woocommerce_api_keys where user_id='{$id}'");
// if($key){
//     $key = base64_encode("ck_".str_replace("ck_","",$key[0]->consumer_key).":cs_".str_replace("cs_","",$key[0]->consumer_secret)); 
//     echo '<script>
//         window.authCode = "'.$key.'";
    
//     </script>';
  
// }else{
//     die("No API KEY FOUND");
// }
?>
<style type="text/css">
    .image_title_price #grid_layout_cycle li span.price{
            line-height: 24px;
    font-size: 14px;    background-color: #fff;
    }
  .loaderabc-block{
    display: none;
    position: absolute;
    top: 0;
    left:0;
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: rgb(249 242 242 / 51%);
  }
  .loaderabc-block img {
    margin: 50px auto;
    position: absolute;
    z-index: 2;
    border-radius: 50%;
    width: 85px;
    height: 85px;
  }
  .loaderabc {
  font-size: 10px;
  margin: 50px auto;
  text-indent: -9999em;
  width: 11em;
  height: 11em;
  border-radius: 50%;
  background: #ffffff;
  background: -moz-linear-gradient(left, #ffffff 10%, rgba(255, 255, 255, 0) 42%);
  background: -webkit-linear-gradient(left, #ffffff 10%, rgba(255, 255, 255, 0) 42%);
  background: -o-linear-gradient(left, #ffffff 10%, rgba(255, 255, 255, 0) 42%);
  background: -ms-linear-gradient(left, #ffffff 10%, rgba(255, 255, 255, 0) 42%);
  background: linear-gradient(to right, #ffffff 10%, rgba(255, 255, 255, 0) 42%);
  position: relative;
  -webkit-animation: load3abc 1.4s infinite linear;
  animation: load3abc 1.4s infinite linear;
  -webkit-transform: translateZ(0);
  -ms-transform: translateZ(0);
  transform: translateZ(0);
}
.loaderabc:before {
  width: 50%;
  height: 50%;
  background: #ffffff;
  border-radius: 100% 0 0 0;
  position: absolute;
  top: 0;
  left: 0;
  content: '';
}
.loaderabc:after {
  background: #0dc5c1;
  width: 75%;
  height: 75%;
  border-radius: 50%;
  content: '';
  margin: auto;
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
}
@-webkit-keyframes load3abc {
  0% {
    -webkit-transform: rotate(0deg);
    transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
    transform: rotate(360deg);
  }
}
@keyframes load3abc {
  0% {
    -webkit-transform: rotate(0deg);
    transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
    transform: rotate(360deg);
  }
}

    #number_order_azp{
        height: 15px;
        width: 15px;
        background: red;
        border-radius: 50%;
        position: absolute;
        text-align: center;
        color: white;
        left: 6px;
        top: 20px;
        display: none;
        line-height: 16px;
    }
        #wc-pos-registers-edit.active{
            pointer-events: none;
            user-select: none;
        }
        #popup{
            position: fixed;
            top: 40%;
            left: 50%;
            transform: translate(-50%,-50%);
            background: #fff;
            padding: 50px;
            width: 100%;
            opacity: 0;
            visibility: hidden;
            transition: 0.5s;
            z-index: 10000;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
        }
        #popup.active{
            top: 50%;
            opacity: 1;
            visibility:visible;
            transition: 0.5s;
        }
       #popup .chon_them_ra label {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  flex-wrap: nowrap;
  margin: 12px 0;
  cursor: pointer;
  position: relative;
}
/* input */
#popup .chon_them_ra input {
  opacity: 0;
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  z-index: -1;
}
/* .design */
#popup .design {
  width: 16px;
  height: 16px;
  border: 1px solid #f00;
  border-radius: 100%;
  margin-right: 5px;
  position: relative;
}
#popup .design.xanh{
  border: 1px solid #39950B;
}
#popup .design.cam{
  border: 1px solid #ff7600;
}
#popup .design.xam{
  border: 1px solid #333333;
}
#popup .design.md{
  border: 1px solid #000;
}
#popup .design.do{
  border: 1px solid #c60c23;
}
#popup .design::before {
  content: "";
  display: block;
  width: inherit;
  height: inherit;
  border-radius: inherit;
  position: absolute;
  transform: scale(0);
  transform-origin: center center;
}
#popup .design.xanh:before {
  background:  #39950B;
  opacity: 0;
}
#popup .design.cam:before {
  background: #ff7600;
  opacity: 0;
}
#popup .design.xam:before {
  background: #333333;
  opacity: 0;
}
#popup .design.md:before {
  background: #000;
  opacity: 0;
}
#popup .design.do:before {
  background: #c60c23;
  opacity: 0;
}
/* .text */
#popup .text {
    color: #000;
    font-size: 16px;
}
/* checked state */
#popup input:checked+.design::before {
  opacity: 1;
  transform: scale(.6);
}
#popup input:checked ~ .text.mau_cam{
color: #ff7600;
}
#popup input:checked ~ .text.mau_xanh{
color: #39950B;
}
#popup input:checked ~ .text.mau_xam{
color: #333333;
}
#popup input:checked ~ .text.mau_do{
color: #c60c23;
}
#popup .title{
    font-size: 20px;
    margin-bottom: 8px;
}
#popup  .chon_them{
        position: absolute;
    width: 500px;
    height: auto;
    top: 50%;
    background: #fff;
    left: 50%;
    border-radius: 10px;
    padding: 40px;
    transform: translate(-50%, -50%);
}
#popup .xac_nhan{
        justify-content: center;
    align-items: center;
    display: flex;
}
#popup .xac_nhan a{
    text-decoration: none;
    display: block;
    width: 90px;
    height: 35px;
    color: #fff;
    text-align: center;
    line-height: 32px;
    border-radius: 10px;
    font-size: 16px;
    font-family: inherit;
}
#popup .xac_nhan a:first-child{
    background:#BE1E2D; 
}
#popup .xac_nhan a:last-child{
   background:  #39950B !important;
   margin-left: 15px;
}
#popup .chon_them_ra{
    display: flex;
    justify-content: space-around;
    margin-bottom: 10px;
}
.close_x{
      width: 100%;
    text-align: right;
    color: #828282;
}
.close_x i{
      position: relative;
    top: -15px;
    font-size: 20px;
}
.hide{display: none !important;}
/**/
#menu_new{
    position: fixed;
    top: 0;
    left: 0;
    transform: translateY(100%);
    background: #fff;
    width: 100%;

    z-index: 10000;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    border-radius: 0;
    display: flex;
  justify-content: center;
  align-items: center;
}
  #menu_new.active{
    opacity: 1;
    visibility: visible;
    z-index: 10;
    transform: translate(0,0);
  }

  #menu_new .frame{
    padding:10px;
    background:#f1f1f1;
    border-radius:24px;
    background:#f9f9f9;
    border: 1px solid #4d4d4d36;
    box-shadow: 0 1px 0px rgba(0,0,0,0.2), 0 1px 1px rgba(0,0,0,0.14), 0 1px 1px -3px rgb(0 0 0 / 0%);
    height: 95%;
    width: 90%;
    overflow-y:scroll;
  }
  #menu_new .head{
    margin:12px auto;
    padding:10px 40px;
    display:flex;
    align-items: center;
    }
  #menu_new .btn{
    margin-left:auto;
    }
  #menu_new .btn-right{
    padding:10px 24px;
    margin-right:25px;
    color:#fff;
    background-color:#fd885e;
    border-radius:24px;
    border:none;
    }
  #menu_new .title{
    padding-left:15px;
  }
  #menu_new .detail{
    border-radius: 5%;
    border: none;
    padding: 15px;
    background: #f1f1f1;
    margin: 10px 10px;
    display: block;
    width: 150px;
    text-decoration: none;
    position: relative;
  }
  #menu_new .img{
    text-align: center;
    border-radius: 50%;
    width: 75px;
    height: 75px;
    margin: auto;
    display: grid;
    place-items: center;
    background: #fff;
    border: 1px solid #f1f1f1;
  }
  #menu_new .img i{
    font-size:45px;
    }
  #menu_new .title-men{
    padding-top:10px;
    }
  #menu_new .title-men h4{
    font-size:20px;
    font-weight:600;
    text-align: center;
    margin:0;    
    }

  #menu_new .detail:hover{
    transition: 0.5s;
    background:#fcd561;
    color:#333;
    text-decoration: none;
    }
  #menu_new .pre{
    width:10%;
    text-align: center;
    font-size:24px;
    }
  #menu_new .next{
    width:10%;
    text-align: center;
    font-size:24px;
    }
  #menu_new .frame-menu{
    display:flex;
    align-items: center
    }
  #menu_new .box-menu{
    flex-wrap: wrap;
    justify-content: flex-start;
    display: flex;
    }
  #menu_new .icon{
    margin: 0 auto;
      width: 50%;
      padding:5px;
    }
  #menu_new .icon:hover{
    cursor: pointer;
    background:#d8d8d873;
    border-radius:5px;
    }
  #menu_new .back i{
    font-size:18px;
    } 
    #menu_new  .container{
      background: transparent;
    }

</style>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
<!-- <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css"> -->
<link rel="stylesheet" href="<?php echo get_theme_root_uri() ?>/woo-child/assets/css/bootstrap.min.css?t=1">
<!-- <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css"> -->
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>


<div class="wrap" id="wc-pos-registers-edit">
    <div id="regiser_top_bar">
        <div class="wp-heading" id="pos_user_badge">
            <div class="menu_bar">
                
                <div class="tieude" onclick="jQuery('.content_menu').toggleClass('show')" style="cursor: pointer;">
                     <i class="fas fa-bars"></i> Menu <span></span>
                </div>
                <div class="content_menu"  style="    width: 200px;top:40px">
                    
                 <a class="" href="#" id="retrieve_sales" style="position: relative;">
                   <i class="fas fa-sync-alt"></i> <span id="number_order_azp">0</span><?php _e('Load', 'wc_point_of_sale'); ?></a>
            <a class="" target="_blank" href="<?php echo $admin_url; ?>admin.php?page=wc-reports" id="retrieve_sales" style="position: relative;"><i class="far fa-file"></i><?php _e('Report', 'wc_point_of_sale'); ?></a>
            <a class="" target="_blank" href="<?php echo $admin_url; ?>edit.php?post_type=product" id="retrieve_sales" style="position: relative;"><i class="fas fa-th-large"></i><?php _e('Product', 'wc_point_of_sale'); ?></a>
            <a class="" target="_blank" href="<?php echo $admin_url; ?>admin.php?page=wc-reports&tab=stock&report=most_stocked" id="retrieve_sales" style="position: relative;"><i class="fas fa-th-large"></i><?php _e('Inventory', 'wc_point_of_sale'); ?></a>

            <?php if (current_user_can('edit_private_shop_orders')) { ?>
                <a class="" target="_blank"
                   href="<?php echo $admin_url; ?>edit.php?post_type=shop_order"
                   id="orders_page" target="_blank"><i class="fas fa-th-large"></i><?php _e('Orders', 'wc_point_of_sale'); ?></a>
            <?php } ?>
            <?php if ($data['float_cash_management']) { ?>
                <a class="" target="_blank"
                   href="<?php echo $admin_url; ?>admin.php?page=wc_pos_cash_management&register=<?php echo $data['ID'] ?>"
                   id="cash_management"><i class="fas fa-money-check-alt"></i><?php _e('Cash Management', 'wc_point_of_sale'); ?></a>
            <?php } ?>
                </div>
            </div>
            <a href="#" class="change_theme page-title-action" onclick="toggle()">
                <i class="fas fa-exchange-alt"></i>
            </a>
            <a class="button"
               href="<?php echo $admin_url; ?>admin.php?page=wc_pos_registers&amp;close=<?php echo $data['ID']; ?>"
               id="close_register"></a>
            <?php $current_user = wp_get_current_user(); ?>
            <a class="pos_register_user_panel" target="_blank" href="<?php echo $admin_url; ?>profile.php">
                <span class="pos_register_user_name"><?php echo $current_user->display_name; ?></span>
                <span class="pos_register_user_image"><?php echo get_avatar($current_user->ID, 64); ?></span>
            </a>
            <a class="tips page-title-action" href="#" id="full_screen"
               data-tip="<?php _e('Full Screen', 'wc_point_of_sale'); ?>"></a>
            <?php if (get_option('wc_pos_lock_screen') == 'yes') { ?>
                <a class="tips page-title-action" href="#" id="lock_register"
                   data-tip="<?php _e('Lock Register', 'wc_point_of_sale'); ?>"></a>
            <?php } ?>
            <?php if (get_option('wc_pos_bill_screen', 'no') == 'yes') { ?>
                <a class="tips page-title-action" href="<?php echo site_url() . '/bill-screen/' . $data['ID']; ?>"
                   id="bill_full_screen" data-tip="<?php _e('View Bill Screen', 'wc_point_of_sale'); ?>"
                   target="_blank"></a>
            <?php } ?>
            <?php if (current_user_can('manage_wc_point_of_sale')) { ?>
                <a class="tips page-title-action" target="_blank"
                   href="<?php echo $admin_url; ?>admin.php?page=wc_pos_settings"
                   id="settings_page" data-tip="<?php _e('Settings', 'wc_point_of_sale'); ?>"></a>
            <?php } ?>

        </div>
        <div class="wp-heading" id="pos_register_buttons">
            <?php $current_user = wp_get_current_user(); ?>
            <a class="pos_register_user_panel <?php echo get_option('woocommerce_pos_register_branding') ?>"
               target="_blank"
               href="<?php echo $admin_url; ?>admin.php?page=wc_pos_registers">
                <span class="pos_register_brand_logo"></span>
                <span class="pos_register_shop_name"><?php echo bloginfo('name') ?></span>
                <span class="pos_register_main_name"><?php echo $data['name'] ?></span>
            </a>
            <?php if (get_option('wc_pos_disable_connection_status', 'yes') != 'yes') { ?>
                <a class="offline-ui-up page-title-action" id="offline_indication">
                    <div class="offline-ui-content"></div>
                    <a class="offline-ui-retry" href=""></a>
                </a>
            <?php } ?>
              <?php if (get_option('wc_pos_tabs_management', 'no') == 'yes') { ?>
                <a class="page-title-action" href="#"
                   id="tabs_page"><?php _e('Tabs', 'wc_point_of_sale'); ?></a>
            <?php } ?>

            <a class="offline_counter page-title-action" id="offline_counter"></a>
            <a class="page-title-action wc_pos_show_tiles " type="button"
               href="#"><?php _e('Show Tiles', 'wc_point_of_sale'); ?></a>
        </div>
    </div>
    <?php
    $revert_columns = get_option('woocommerce_pos_register_revert_columns', 'yes');
    ?>
    <div id="edit_wc_pos_registers">
        <div id="poststuff">
            <div id="post-body" class="metabox-holder columns-2">
                <div id="postbox-container-<?php echo ($revert_columns == 'no' || !$revert_columns) ? '1' : '2' ?>"
                     class="postbox-container product-panel <?php echo get_option('woocommerce_pos_register_size', 'twenty') ?>">
                    <div id="wc-pos-register-search-products" class="postbox">
                        <div class="hndle">
                            <div class="add_items">
                                <?php if (WC_VERSION >= 3) { ?>
                                    <form autocomplete="off" onsubmit="preventDefault()">
                                        <select id="add_product_id" class="ajax_chosen_select_products_and_variations"
                                                data-placeholder="<?php _e('Search Products', 'wc_point_of_sale'); ?>"
                                                data-allow-clear="true"></select>
                                    </form>
                                <?php } else { ?>
                                    <input id="add_product_id" class="ajax_chosen_select_products_and_variations"
                                           data-placeholder="<?php _e('Search Products', 'wc_point_of_sale'); ?>"/>
                                <?php } ?>
                            </div>
                            <span class="clearfix"></span>
                        </div>
                    </div>
                    <div id="wc-pos-actions" class="postbox">
                        <?php if (get_option('wc_pos_print_diner_option', 'no') == 'yes'): ?>
                            <a class="button" id="add_dining_option"
                               data-modal="modal-dining_option"><span class="selected-dining">
                                    <?php if (isset($data['dining_option_default'])): ?>
                                        <?php echo (($data['dining_option_default'] != 'none') ? __(str_replace('_', ' ', $data['dining_option_default']), 'wc_point_of_sale'): __($data['dining_option_default'], 'wc_point_of_sale')) ?>
                                    <?php else: ?>
                                        <?php _e('None', 'wc_point_of_sale') ?>
                                    <?php endif; ?>
                                </span>
                            </a>
                        <?php endif; ?>
                        <a class="button wc_pos_register_customer" id="add_customer_to_register"
                           data-modal="modal-order_customer"><?php _e('Customer', 'wc_point_of_sale'); ?></a>
                        <?php if (get_option('woocommerce_calc_shipping') == 'yes') { ?>
                            <a class="button" id="add_shipping_to_register"
                               data-modal="modal-add_custom_shipping">
                                <?php _e('Shipping', 'wc_point_of_sale'); ?>
                            </a>
                        <?php } ?>
                        <a class="button wc_pos_register_notes " type="button"
                           href="#"><?php _e('Note', 'wc_point_of_sale'); ?>
                        </a>
                        <?php
                        $discount = esc_attr(get_user_meta(get_current_user_id(), 'discount', true));
                        if ($discount != 'disable' && get_option('woocommerce_enable_coupons') == 'yes'): ?>
                            <a class="button  wc_pos_register_discount " type="button"
                               href="#"><?php _e('Discount', 'wc_point_of_sale'); ?>
                            </a>
                        <?php endif; ?>
                        <?php if (get_option('wc_pos_custom_fee', 'no') == 'yes') { ?>
                            <a class="button  wc_pos_register_custom_fee" type="button"
                               href="#"><span
                                        class="currency_symbol"><?php echo get_woocommerce_currency_symbol(); ?></span><?php _e('Fee', 'wc_point_of_sale'); ?>
                            </a>
                        <?php } ?>
                        <?php if (get_option('wc_pos_refund', 'no') == 'yes') { ?>
                            <a class="button" id="wc_pos_create_refund" href="#">
                                <?php _e('Refund', 'wc_point_of_sale'); ?>
                            </a>
                        <?php } ?>
                        <a class="button" id="add_product_to_register"
                           data-modal="modal-add_custom_product"><?php _e('Product', 'wc_point_of_sale'); ?></a>
                        <?php if (class_exists('acf') && get_option('wc_pos_integrate_order_field', 'no') === "yes"): ?>
                            <a class="button" id="acf_order_info"
                               data-modal="modal-acf_order_information"><?php _e('Information', 'wc_point_of_sale'); ?></a>
                        <?php endif; ?>
                        <a class="tips button ladda-button " data-spinner-color="#6d6d6d" id="sync_data"
                           data-tip='<span id="last_sync_time"></span>'>
                            <span class="ladda-label"></span><?php _e('Sync', 'wc_point_of_sale'); ?></a>
                    </div>
                    <div id="wc-pos-register-grids" class="postbox">
                        <div class="tbc">
                            <?php
                            $pos_layout = get_option('woocommerce_pos_second_column_layout', 'product_grids');

                            if ($pos_layout == 'product_grids') :
                                $grid_id = $data['grid_template'];
                                if ($grid_id == 'all') {
                                    ?>
                                    <h3 class="hndle">
                                        <span id="wc-pos-register-grids-title"><?php _e('All Products', 'wc_point_of_sale'); ?></span>
                                        <i class="close_product_grids"></i>
                                    </h3>
                                    <?php
                                } else if ($grid_id == 'categories') {
                                    ?>
                                    <h3 class="hndle">
                                        <span id="wc-pos-register-grids-title" class="cat_title"
                                              data-parent="0"><?php _e('Categories', 'wc_point_of_sale'); ?></span>
                                        <i class="close_product_grids"></i>
                                    </h3>
                                    <?php
                                } else {
                                    $grids_single_record = wc_point_of_sale_tile_record($grid_id);
                                    $grids_all_record = wc_point_of_sale_get_all_grids($grid_id);
                                    ?>
                                    <h3 class="hndle">
                                        <span id="wc-pos-register-grids-title"><?php if (!empty($grids_single_record)) _e(ucfirst($grids_single_record[0]->name) . ' Layout', 'wc_point_of_sale') ?></span>
                                        <i class="close_product_grids"></i>
                                    </h3>
                                    <?php
                                } ?>
                                <div class="inside" id="grid_layout_cycle" data-offset="0" data-parent="0"><ul></ul></div>
                                <!-- <div class="previous-next-toggles">
                                    <span class="previous-grid-layout tips"
                                          data-tip="<?php /*_e('Previous', 'wc_point_of_sale'); */
                                ?>"></span>
                                    <div id="nav_layout_cycle_wrap">
                                        <div id="nav_layout_cycle"></div>
                                    </div>
                                    <span class="next-grid-layout tips"
                                          data-tip="<?php /*_e('Next', 'wc_point_of_sale'); */
                                ?>"></span>
                                </div>-->
                                <?php
                            else: ?>
                                <div class="inside" id="grid_layout_cycle" data-offset="0">
                                    <?php if ($pos_layout == 'company_image') {
                                        $woocommerce_pos_company_logo = get_option('woocommerce_pos_company_logo', '');
                                        $src = '';
                                        if (!empty($woocommerce_pos_company_logo)) {
                                            $src = wp_get_attachment_image_src($woocommerce_pos_company_logo, 'full');
                                            $src = $src[0];
                                        }
                                        ?>
                                        <div class="grid_logo">
                                            <img src="<?php echo $src; ?>" alt="">
                                        </div>
                                    <?php } elseif ($pos_layout == 'text') { ?>
                                        <div class="grid_text">
                                            <?php echo get_option('woocommerce_pos_register_layout_text', ''); ?>
                                        </div>
                                    <?php } elseif ($pos_layout == 'company_image_text') {
                                        $woocommerce_pos_company_logo = get_option('woocommerce_pos_company_logo', '');
                                        $src = '';
                                        if (!empty($woocommerce_pos_company_logo)) {
                                            $src = wp_get_attachment_image_src($woocommerce_pos_company_logo, 'full');
                                            $src = $src[0];
                                        }
                                        ?>
                                        <div class="grid_logo" style="height: 33%; ">
                                            <img src="<?php echo $src; ?>" alt="">
                                        </div>
                                        <div class="grid_text" style="height: 67%; ">
                                            <?php echo get_option('woocommerce_pos_register_layout_text', ''); ?>
                                        </div>
                                    <?php } ?>
                                </div>
                                <?php
                            endif; ?>
                        </div>
                    </div>
                </div>
                <div id="postbox-container-<?php echo ($revert_columns == 'no' || !$revert_columns) ? '2' : '1' ?>"
                     class="postbox-container customer-panel <?php echo get_option('woocommerce_pos_register_size', 'twenty') ?>">
                    <div id="wc-pos-customer-data" class="postbox ">
                        <div class="hndle">
                            <div class="add_items">
                                <?php if (!isMobilePOS()) { ?>
                                    <?php if (WC_VERSION >= 3) { ?>
                                        <select id="customer_user" class="ajax_chosen_select_customer"
                                                data-placeholder="<?php _e('Search Customers', 'wc_point_of_sale'); ?>"
                                                autocompleate="off"></select>
                                    <?php } else { ?>
                                        <input id="customer_user" class="ajax_chosen_select_customer"
                                               data-placeholder="<?php _e('Search Customers', 'wc_point_of_sale'); ?>"
                                               autocompleate="off"/>
                                    <?php } ?>
                                <?php } else { ?>
                                    <a class="tips" id="search_customer_to_register" type="button"
                                       data-tip="<?php _e('Search Customer', 'wc_point_of_sale'); ?>"><span></span></a>
                                <?php } ?>
                            </div>
                            <span class="clearfix"></span>
                        </div>
                        <div class="inside">
                            <div class="woocommerce_order_items_wrapper">
                                <table class="woocommerce_order_items" cellspacing="0" cellpadding="0">
                                    <tbody id="customer_items_list">
                                    <?php
                                    $user_to_add = absint($data['default_customer']);
                                    pos_get_user_html($user_to_add);
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div id="wc-pos-register-data" class="postbox ">
                        <div class="tbc">
                            <div class="tb">
                                <div class="inside tbr">
                                    <div class="tb" id="bill_screen">
                                        <?php if (get_option('wc_pos_tabs_management', 'no') == 'yes') { ?>
                                            <div class="tab-tabs">
                                                    <span class="tab active main"
                                                          data-tab_id="main"><?php echo __('Take Away', 'wc_point_of_sale') ?></span>
                                            </div>
                                        <?php } ?>
                                        <div class="woocommerce_order_items_wrapper tbr">
                                            <?php if (get_option('wc_pos_tabs_management', 'no') == 'no') { ?>
                                                <div class="tbc tab active" id="woocommerce_order_items-container">
                                                    <div id="order_items_list-wrapper">
                                                        <table class="woocommerce_order_items labels" cellspacing="0"
                                                               cellpadding="0">
                                                            <tbody id="order_items_list">
                                                            <?php
                                                            $order = new WC_Order($data['order_id']);
                                                            ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            <?php } else { ?>
                                                <div class="tbc tab active main"
                                                     id="tab-main" data-tab_id="main" data-tab_number="main">
                                                    <table class="woocommerce_order_items labels" cellspacing="0"
                                                           cellpadding="0">
                                                        <thead>
                                                        <tr>
                                                            <th class="item"><?php _e('Product', 'wc_point_of_sale'); ?></th>
                                                            <th class="quantity"><?php _e('Qty', 'wc_point_of_sale'); ?></th>
                                                            <?php do_action('wc_pos_tmpl_cart_product_item_thead'); ?>
                                                            <th class="line_cost_total"><?php _e('Total', 'wc_point_of_sale'); ?></th>
                                                        </tr>
                                                        </thead>
                                                    </table>
                                                    <div id="order_items_list-wrapper">
                                                        <table class="woocommerce_order_items" cellspacing="0"
                                                               cellpadding="0">
                                                            <tbody id="order_items_list">
                                                            <?php $order = new WC_Order($data['order_id']); ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            <?php } ?>
                                        </div>
                                        <div class="wc_pos_register_subtotals tbr">
                                            <table class="woocommerce_order_items" cellspacing="0" cellpadding="0">
                                                <tr id="tr_order_subtotal_label">
                                                    <th class="subtotal_label"><?php _e('Subtotal', 'wc_point_of_sale'); ?></th>
                                                    <td class="subtotal_amount">
                                                        <span id="subtotal_amount"><?php echo wc_price(0); ?></span>
                                                    </td>
                                                </tr>
                                                <?php /********************************/ ?>
                                                <?php
                                                if (isset($detail_data['default_shipping_method']) && $detail_data['default_shipping_method'] != ''){
                                                ?>
                                            <tr class="shipping_methods_register" style="display: table-row;">
                                            <?php
                                            }else{
                                            ?>
                                                <tr class="shipping_methods_register">
                                                    <?php } ?>
                                                    <th>
                                                        <?php
                                                        if (isset($detail_data['default_shipping_method']) && $detail_data['default_shipping_method'] != '') {
                                                            _e('Shipping and Handling', 'woocommerce');
                                                        }
                                                        ?>
                                                    </th>
                                                    <td>
                                                        <?php
                                                        if (isset($detail_data['default_shipping_method']) && $detail_data['default_shipping_method'] != '') {
                                                            $chosen_method = $detail_data['default_shipping_method'];
                                                            $shipping_methods = WC()->shipping->load_shipping_methods();
                                                            ?>
                                                            <select name="shipping_method[0]" data-index="0"
                                                                    id="shipping_method_0" class="shipping_method">
                                                                <option value="no_shipping" <?php selected('no_shipping', $chosen_method); ?>
                                                                        data-cost="0"><?php _e('No Shipping', 'wc_point_of_sale'); ?></option>
                                                                <?php
                                                                foreach ($shipping_methods as $key => $method) {
                                                                    ?>
                                                                    <option value="<?php echo esc_attr($method->id); ?>" <?php selected($method->id, $chosen_method); ?>
                                                                            data-cost="<?php echo isset($method->cost) ? $method->cost : 0; ?>"><?php echo $method->get_title(); ?><?php echo isset($method->cost) ? wc_price($method->cost) : ''; ?></option>
                                                                    <?php
                                                                }
                                                                ?>
                                                            </select>
                                                            <?php
                                                        }
                                                        ?>
                                                    </td>
                                                </tr>
                                                <?php if (get_option('wc_pos_custom_fee', 'no') == 'yes') { ?>
                                                    <tr class="fee_row">
                                                        <td colspan="2" class="fee_col">
                                                            <table></table>
                                                        </td>
                                                        <!-- <th class="tax_label"><?php _e('Tax', 'wc_point_of_sale'); ?></th>
                                                    <td class="tax_amount"><strong id="tax_amount"></strong></td> -->
                                                    </tr>
                                                <?php } ?>
                                                <?php
                                                /********************************/
                                                if (wc_pos_tax_enabled()) {
                                                    ?>
                                                    <tr class="tax_row">
                                                        <td colspan="2" class="tax_col">
                                                            <table></table>
                                                        </td>
                                                        <!-- <th class="tax_label"><?php _e('Tax', 'wc_point_of_sale'); ?></th>
                                                    <td class="tax_amount"><strong id="tax_amount"></strong></td> -->
                                                    </tr>
                                                    <?php
                                                } ?>
                                                <?php if ($d = $order->get_total_discount()) { ?>
                                                    <tr id="tr_order_discount">
                                                        <th class="total_label"><?php _e('Order Discount', 'wc_point_of_sale'); ?>
                                                            <span id="span_clear_order_discount"></span>
                                                        </th>
                                                        <td class="total_amount">
                                                            <input type="hidden" value="<?php echo $d; ?>"
                                                                   id="order_discount" name="order_discount">
                                                            <span id="formatted_order_discount"><?php echo wc_price($d, array('currency' => $order->get_order_currency())); ?></span>

                                                        </td>
                                                    </tr>
                                                <?php } ?>
                                                <tr id="tr_order_total_label">
                                                    <th class="total_label"><?php _e('Total', 'wc_point_of_sale'); ?></th>
                                                    <td class="total_amount"><strong
                                                                id="total_amount"><?php echo wc_price(0); ?></strong>
                                                    </td>
                                                </tr>

                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php $disable_pay = get_user_meta($current_user->ID, 'disable_pos_payment', true); ?>
                    <div id="wc-pos-register-buttons" class="postbox <?php echo $disable_pay != 'yes' ? 'pay_enabled' : 'pay_disabled'; ?>">
                        <div class="tbc">
                            <div class="tb">
                                <div class="tbr">
                                    <div class="wc_pos_register_void page-title-action"
                                         type="button"><?php _e('Void', 'wc_point_of_sale'); ?></div>
                                    <div class="wc_pos_register_save page-title-action"
                                         type="submit"><?php echo (get_option('wc_pos_tabs_management', 'no') == 'no') ? __('Save', 'wc_point_of_sale') : __('Order', 'wc_point_of_sale'); ?></div>
                                    <?php if($disable_pay != "yes"): ?>
                                    <div class="wc_pos_register_pay page-title-action"
                                         type="button"><?php _e('Pay', 'wc_point_of_sale'); ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
</div>
<!--  -->
<div id="popup">
          <div class="chon_them">
            <div class="close_x">
                <i class="fas fa-times" onclick="toggle()"></i>
            </div>
              <div class="title">
                  Mẫu giao diện
              </div>
              <div class="chon_them_ra">
                 <!-- <label>
                  <input type="radio" value="color_md" data-theme="color_system" name="dl_theme" checked>
                  <span class="design md"></span>
                  <span class="text">Mặc Định</span>
                </label> -->

                <label>
                  <input type="radio" value="color_cam" data-theme="color_cam" name="dl_theme" checked="">
                  <span class="design cam"></span>
                  <span class="text mau_cam">Màu Cam</span>
                </label>

                <label>
                  <input type="radio" value="color_xanh" name="dl_theme">
                  <span class="design xanh"></span>
                  <span class="text mau_xanh">Màu Xanh</span>
                </label>

                <label>
                  <input type="radio" value="color_xam" name="dl_theme">
                  <span class="design xam"></span>
                  <span class="text mau_xam">Màu Xám</span>
                </label>

                 <label>
                  <input type="radio" value="color_do" name="dl_theme">
                  <span class="design do"></span>
                  <span class="text mau_do">Màu Đỏ</span>
                </label>
              </div>
              <!--  -->
              <div class="thoigian_in">
                <div class="title">
                  Thời gian In
              </div>
              <div>
                <label for="asyn_timer">Thời gian đồng bộ in ấn(thời gian)</label>
                <input type="text" id="asyn_timer" value="10" min="10" max="1000" placeholder="" />
              </div>
              </div>
          
              <!--  -->
              <div class="sound_time">
                  <div class="title">
                  Âm thanh
              </div>
                <div class="detail_sound">
                <form method="post" name="quangcao" class="quangcaonew" id="quangcaoform" target="create_ads" enctype="multipart/form-data" action="">
                  <label for="sound_coming">Âm thanh khi có đơn hàng mới</label>
                 <input type="file" id="sound_coming" name="sound_coming" />
                 <button>Tải lên</button>
                 <div class="video_ads_show hide">
                  <p>Review in https://fpt.ai/tts</p>
                  <audio src="" controls playsinline></audio>
                 </div>
                </form>
                <iframe src="" name="create_ads" class="create_ads"></iframe>
                <script>
                  setTimeout(function(){
                    jQuery(document).ready(function($){
                       $(".file_video").on("change",function(){
                        var fileUrl =   URL.createObjectURL(this.files[0]);
                         $(".video_ads_show").removeClass("hide").find("audo").attr("src", fileUrl);
                      });
                    });
                  },3000);
                </script>
              </div>
              </div>
          </div>
    </div>
    <!--  -->
    <div id="menu_new" class="animate__animated hide" data-go="animate__fadeInUp">
      
          <div class="frame">
            <div class="row hide">
              <div class="head">
                <div class="btn">
                  <button type="button" class="btn-right btn-go-menu">
                     <i class="fas fa-times"></i>
                  </button>
                </div>
              </div>
            </div>
            <div class="box-menu">
              <a href="#" onclick="$('.menu_bar').trigger('click');return false;">
                <div class="img">
                  <img width="45" src="https://www.flaticon.com/svg/static/icons/svg/2223/2223615.svg" alt="">
                </div>
                <div class="title-men">
                  <h4>Trở lại</h4>
                </div>
              </a>
            </div>
            <?php
               do_action("pos_render_client",$data);
            ?>  
          </div>
    </div>
<?php
$need_sync = 0;
if (isset($data['detail']['need_sync']) && $data['detail']['need_sync']) {
    $need_sync = 1;
    $data['detail']['need_sync'] = 0;
    WC_Pos_Registers::update_detail($data['ID'], $data['detail']);
}
//var_dump($data);
?>

<script>
  
    var change_user = <?php echo json_encode(isChangeUserAfterSale($data['ID'])); ?>;
    var note_request = <?php echo json_encode(isNoteRequest($data['ID'])); ?>;
    var print_receipt = <?php echo json_encode(isPrintReceipt($data['ID'])); ?>;
    var email_receipt = <?php echo absint($data['settings']['email_receipt']); ?>;
    var disable_sale_prices = <?php echo (isset($data['detail']['disable_sale_prices'])) ? absint($data['detail']['disable_sale_prices']) : 0; ?>;
    var need_register_sync = <?php echo absint($need_sync); ?>;
    var wc_version = <?php echo floatval(WC_VERSION); ?>

   function toggle(){
        var blur=document.getElementById('wc-pos-registers-edit');
        blur.classList.toggle('active');
        var popup=document.getElementById('popup');
        popup.classList.toggle('active');
    }
    // $(document).ready(function() {
    //   $('.tieude').click(function (e) {
    //     $('.content_menu').stop(true).slideToggle();
    //   });
    //   $(document).click(function (e) {
    //     if (!$(e.target).closest('.tieude, .content_menu').length) {
    //       $('.content_menu').stop(true).slideUp();
    //     }
    //   });
    // $("#modal-tabs .nav-tab").click(function(){
    //     $(this).addClass("mo-tab").siblings().removeClass("mo-tab");
    // });
    // });
    
</script>

<!-- Modal -->
<style type="text/css">
  #MyIframe{
    overflow:hidden!important;
    padding-left: 0!important;
    
  }
  #MyIframe .modal-dialog{
    width: 99%;
    height: 99%;
        padding: 0;
    margin: 0 auto;
  }
 #MyIframe .modal-content{
    width: 100%;
    height: 100%;
         display: flex;
    flex-direction: column;
  }
  #MyIframe .modal-body{
    padding: 0;
    flex: 1;
  }
  #MyIframe .modal-body .scroll{
    height: 100%;
  }
  #MyIframe .modal-body iframe{
    width: 100%;
    height: 100%;
    border:0;
  }
</style>
<div class="modal fade" id="MyIframe" role="dialog" aria-labelledby="MymodalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true" title="close">Đóng x</button>
          <h4 class="modal-title">Quản trị</h4>
        </div>
        <!--  -->
        <div class="modal-body">
           <div class="loaderabc-block">
              <img src="<?php echo LOGO ?>" width="75" alt="">
              <div class="loaderabc">
                
              </div>
           </div>
           <div class="scroll">
                <iframe src=""></iframe>   
           </div>
        </div>
        <!--  -->
      </div>
    </div>
</div>
<!-- End Modal -->

<!-- Modal -->
<div class="modal fade" id="SettingBox" role="dialog" aria-labelledby="MymodalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true" title="close">x</button>
          <h4 class="modal-title"><?php _e('Settings', 'wc_point_of_sale'); ?></h4>
        </div>
        <div class="modal-body">
          <div>
              <ul class="nav nav-pills" role="tablist" data-tabs="tabs">
              <li class="active"><a href="#SettingGeneral" data-toggle="tab">Tổng Quan</a></li>
              <li><a href="#SettingKeyPress" data-toggle="tab">Key press</a></li>
              </ul>
              <div class="tab-content">
                 <div role="tabpanel" class="tab-pane fade in active" id="SettingGeneral">
                      <form action="" method="post" enctype="multipart/form-data">
                         <div class="alert alert-warning" style="display: none;"></div>
                        <div class="form-group">
                         <label for="">xxx <b class="text-red">*</b></label>
                         <input type="text" value=""  class="form-control required">
                          </div>
                     </form>
                 </div>
                <div role="tabpanel" class="tab-pane fade in" id="SettingKeyPress">
                    <form action="" method="post" enctype="multipart/form-data">
                       <table class="table">
                        <thead>
                          <th>Tên KeyPress</th>
                          <th>Thông tin</th>
                        </thead>
                         <tbody>
                          <tr>
                             <td>Đến menu</td>
                             <td><input type="text" class="form-control keypress" name="keypress[menu]" placeholder="Enter key" value="f5"></td>
                           </tr>
                           <tr>
                             <td>In Hoá đơn nhanh</td>
                             <td><input type="text" class="form-control keypress" name="keypress[print]" placeholder="Enter key" value="ctrol+p"></td>
                           </tr>
                           <tr>
                             <td>Xoá bill hiện tại</td>
                             <td><input type="text" class="form-control keypress" name="keypress[delete_bill]" placeholder="Enter key" value="ctrol+x"></td>
                           </tr>
                         </tbody>
                       </table>
                   </form>
                </div>
              </div>
          </div>
           
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Đóng</button>
         
        </div>
      </div>
    </div>
</div>

<script>
setTimeout(function(){
    //
    window.$ = window.jQuery;
    $("body").append('<script src="<?php echo get_theme_root_uri() ?>/woo-child/assets/js/bootstrap.min.js"><\/script><script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js"><\/script>');
    jQuery(document).ready(function($){

      // $("[data-go]").on('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend',
      // function(){ 
      //     $(this).removeClass($(this).data("go"));
      // });

      $(document).on("click",".menu_bar",function(e){
        e.preventDefault();
        var blur=$('#wc-pos-registers-edit');
        blur.toggleClass('active');
        var popup=$('#menu_new');
        popup.toggleClass('animate__fadeInUp');
      });

        var submit = false;
    

  
  $('#SettingBox').on('shown.bs.modal', function (e) {
    var who = $(e.relatedTarget);
       $(this).find("form")[0].reset();
  });
  $('#SettingBox').on('hidden.bs.modal', function (e) {
      var who = $(e.relatedTarget);
         $(this).find("form")[0].reset();
  });


  jQuery(document).ready(function($){
      var submit = false;
      var modal = $("#MyIframe");
      
      modal.on('shown.bs.modal', function (e) {
        $("html").addClass("modal-open");
        modal.find(".loaderabc-block").fadeIn();

      }).on('hidden.bs.modal', function (e) {
        var who = $(e.relatedTarget);
        $("html").removeClass("modal-open");
        modal.find("iframe").attr("src","");
      });

    //   modal.find("iframe").on("load",function () {
    //     modal.find(".modal-title").html(this.contentDocument.title);

    //     modal.find(".loaderabc-block").fadeOut();
    //     var frame1ChildWindow = this.contentWindow;
    //     $( frame1ChildWindow ).unload(function() {
    //       modal.find(".loaderabc-block").fadeIn();
    //     });
    //   });
    //   jQuery("#close_register,#pos_user_badge .pos_register_user_panel").addClass("detail");
    //   jQuery("#pos_register_buttons a").attr("href","#");

    //   jQuery(document).on("click","a.detail",function(e){
    //       e.preventDefault();
    //       modal.find("iframe").attr("src",this.href);
    //       modal.modal();
    //   }); 
    });



  // jQuery("#SettingBox form").validate({
  //     submitHandler : function(form){
  //       if(submit){
  //           return;
  //        }

  //        var error_div = $(form).find(".alert-warning");

  //        //allow
  //        submit = true;
  //        var data= $(form).serializeObject();
  //        //valdiate again

  //        error_div.html("Loading...").fadeIn();

  //        post(site_url_ajax("..."),{ahlu:JSON.stringify(data)},function(res){
  //       submit = false;
  //           try{
  //              res = JSON.parse(res.trim());
  //           }catch(ex){
  //              console.log(ex);
  //           }

  //           if(typeof res==="object"){
  //              if(res.code==1){
  //                  error_div.html(res.message).fadeIn();
  //              }else{
  //                 error_div.html(res.error).fadeIn(); 
  //              }
  //           }else{
  //              error_div.html(res).fadeIn();
  //           }
  //           setTimeout(function(){
  //                 error_div.fadeOut();
  //           },3000);
  //        },true);
  //     }
  //   });
 });
},5*1000);
</script>
<!-- End Modal -->