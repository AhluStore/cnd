<!-- Tabs popup-->
<?php
// print_r($data);
// die();
$custom_taxonomy='cate_table';  
$cates = get_terms($custom_taxonomy);   
?>
<div class="md-modal md-dynamicmodal md-register md-close-by-overlay" id="modal-tabs">
    <span class="md-close" style="right: 30px;">Đóng</span>
    <div class="md-content woocommerce">

        <h1>
            <span><?php _e('Bàn', 'wc_point_of_sale'); ?> </span>
            
            
        </h1>
        <ul class="nav nav-pills" role="tablist" data-tabs="tabs">
                <li class="active"><a href="#Tablist" data-toggle="tab">Bàn/Ghế</a></li>
                <li><a href="#TableTakeaway" class="TableTakeaway" onclick="$('#modal-tabs .right-col').toggleClass('active')">Takeaway</a></li>
                <!-- <li><a href="#Tabsetting" data-toggle="tab">Cài đặt</a></li> -->
            </ul>
        <div class="body">
        <div class="left-col-region hide">
            <div class="flex-body">
                <!-- <a href="#table_region_all" data-tab="all" class="nav-tab">Tất cả</a> -->
                <?php
                   // $args = array(
                   //      'type'=> 'table_manager',
                   //     'taxonomy' => 'cate_table'
                   // );

                 // global $wpdb; 
            
                 // $cates =  $wpdb->get_results("select * from {$wpdb->terms} cate
                 //    join {$wpdb->term_taxonomy}  taxonomy on taxonomy.term_id = cate.term_id
                 // where taxonomy.taxonomy='cate_table'");
            
                   foreach($cates as $cat) {
                ?>
                    <a href="#table_region_<?php echo $cat->term_id; ?>" data-tab="<?php echo $cat->term_id; ?>" class="nav-tab"><?php echo $cat->name; ?></a>
                     
                <?php
                   }
                ?>
                
            </div>
        </div>
        <!--  -->
        <div class="left-col ">
            <!--  load tabel tab -->
            
                
                <div class="tab-content">
                   <div role="tabpanel" class="tab-pane fade in active table-tabs" id="Tablist">
                        
                   </div>
                  <div role="tabpanel" class="tab-pane fade in" id="Tabsetting">
                       <div class="form-group">
                            <label for="xxx">Cài đặt danh sách bàn</label>
                            <textarea style="height:300px" class="form-control"></textarea>
                            <small class="form-text text-muted">Dùng dữ liệu mẫu <span class="btntabdemo">Tại đây</span></small>
                       </div>
                       <div class="text-center">
                            <a href="#" class="button button-primary wp-button-large" id="confirm_tab_save"><?php _e('Cập nhật', 'wc_point_of_sale') ?></a>
                       </div>
                  </div>
                </div>
      
           
            <!--  -->
        </div>
        <!--  -->
        <div class="right-col">
            <div class="showinmobile">
                <span class="">Đóng</span>
            </div>
            <div class="content">
                <div class="select-tab"><p><?php _e('Vui lòng chọn bàn', 'wc_point_of_sale') ?></p></div>
                <div class="select-tab"><p><?php _e('Please select a tab', 'wc_point_of_sale') ?></p></div>
                <div class="tab-form">
                    <p class="tab_open_header" style="display: none;">
                        <?php _e('You are about to open', 'wc_point_of_sale') ?>
                    </p>
                    <p class="tab_open_number">
                        <span class="tab-number"><?php _e('Bàn Mang đi', 'wc_point_of_sale') ?></span>
                    </p>
                    <div class=" " style="    display: flex;flex-direction: row;">
                        <p>
                            <label for="tab-title"><?php _e('Tên Bàn', 'wc_point_of_sale') ?></label>
                            <input type="text" id="tab-title" value="Takeaway">
                        </p>
                        <p class="tablimitblock">
                            <label for="tab-limit"><?php _e('Chi tối thiểu', 'wc_point_of_sale') ?></label>
                            <input type="number" id="tab-limit" min="0">
                        </p>
                    </div>

                    <div class="text-center" style="margin-top: 8px;">
                        <a href="#" class="button button-primary wp-button-large"
                       id="open_new_tab"><?php _e("Xác nhận", 'wc_point_of_sale') ?></a>
                    </div>

                    <hr>
                    <div id="tab-task">
                        <div class="flex-col" style="    display: flex;flex-direction: row;justify-content: space-around; padding: 8px;">
                            <span>
                                <input type="radio" id="move_table" name="ac" />
                                <label for="move_table">Chuyển bàn</label>
                                
                            </span>
                            <span>
                                <input type="radio" id="merge_table" name="ac" />
                                <label for="merge_table">Nhập bàn</label>
                            </span>
                        </div>
                        <div class="tab-actions">
                            <div class="move_table hide">
                                <select id="select"></select>
                            </div>
                            <div class="merge_table hide">
                                <select  id="select_from" multiple="multiple"></select>
                                <span>đến</span>
                                <select  id="select_to"></select>
                            </div>
                            
                        </div>
                    </div>
                    <div class="text-center">
                    <a href="#" class="button button-primary wp-button-large" style="display: none;" id="confirm_tab"><?php _e("OK", 'wc_point_of_sale') ?></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
</div>
<script type="text/javascript">
  setTimeout(function(){
      jQuery(document).ready(function($) {
      var currSeconds = 0;

        /* Increment the idle time
            counter every second */
        var idleInterval = setInterval(function () {
            currSeconds = currSeconds + 1;
            if(currSeconds>30){
              //reset
               currSeconds = 0;
               jQuery("#tabs_page").trigger('click');
            }
        }, 2000);
        $(this).on("mousemove keypress touchmove",function() { 
            currSeconds = 0;
        });
    });
  },4000);  
</script>