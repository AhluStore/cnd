<div class="md-modal md-dynamicmodal md-message" id="modal-permission-denied">
    <div class="md-content">
	    <div>
            <div class="md-message-icon">
        		<span class="dashicons printing-receipt-icon"></span>
        	</div>
		    <p><?php _e( 'You do not have permission to access this register.', 'wc_point_of_sale' ); ?></p>
		    <a class="button" href="<?php echo admin_url('admin.php?page=wc_pos_registers' ); ?>"><?php _e( 'All Registers', 'wc_point_of_sale' ); ?></a>
        </div>
	</div>
</div>