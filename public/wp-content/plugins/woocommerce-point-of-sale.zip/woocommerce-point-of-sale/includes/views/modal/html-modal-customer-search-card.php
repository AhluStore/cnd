<div class="md-modal md-dynamicmodal md-close-by-overlay md-register" id="modal-customer-search-card">
    <div class="md-content">
        <h1><?php _e('Swipe Card', 'wc_point_of_sale'); ?><span class="md-close close-order-comments"></span></h1>
        <div id="pos_card_fields" class="pos-customer-details-tab" style="padding: 0 2em !important;">
            <div class="woocommerce-additional-fields">
                <input type="hidden" id="swiped">
                <p>Please swipe the card which you want to assign to this user.</p>
                <div class="result"></div>
            </div>
        </div>
    </div>
</div>