<?php

class WC_Pos_Tab
{
}