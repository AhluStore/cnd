<?php

class MySQLCacheSource implements CacheSource
{
    public function saveProducts($products)
    {
        // TODO: Implement saveProducts() method.
    }

    public function loadProducts($products)
    {
        // TODO: Implement loadProducts() method.
    }
}