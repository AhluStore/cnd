var Constants = {
	PLUGIN_NAME: 'timer',
	TIMER_RUNNING: 'running',
	TIMER_PAUSED: 'paused',
	DAYINSECONDS: 86400
};
